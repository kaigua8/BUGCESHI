

from slot_manager_data_types import SlotInfo
from rvc_pipeline import RVCPipeline

class PipelineManager:

    @classmethod
    def get_pipeline(cls, slot_info: SlotInfo):
        if slot_info.voice_changer_type == 'Beatrice_v2':
            from .beatricev2_pipeline import BeatriceV2Pipeline
            beatrice_v2_pipeline = BeatriceV2Pipeline(slot_info)
            return beatrice_v2_pipeline
        if slot_info.voice_changer_type == 'RVC':
            rvc_pipeline = RVCPipeline(slot_info)
            return rvc_pipeline
        raise ValueError(f'Unknown voice changer type:{slot_info.voice_changer_type}')