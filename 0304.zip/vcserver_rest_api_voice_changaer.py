

import logging
from fastapi import APIRouter
from fastapi.responses import Response
from fastapi import File, UploadFile, Header
import numpy as np
from pydantic import BaseModel
from const import LOGGER_NAME
from event_emitter_manager import EventEmitterManager
from validation_error_logging_route import ValidationErrorLoggingRoute
from configuration_manager import ConfigurationManager
from voice_changer_data_types import VoiceChangerManagerInfo
from local_voice_changer_interface import LocalVoiceChangerInterface
from voice_changer import VoiceChanger
from voice_changer_manager import VoiceChangerManager

class ConvertFileParam(BaseModel):
    src_path: str
    dst_path: str

class RestAPIVoiceChanger:

    def __init__(self):
        self.router = APIRouter()
        self.router.route_class = ValidationErrorLoggingRoute
        self.router.add_api_route('/api/voice-changer/convert_chunk', self.post_convert_chunk, methods=['POST'])
        self.router.add_api_route('/api/voice-changer/convert_chunk_bulk', self.post_convert_chunk_bulk, methods=['POST'])
        self.router.add_api_route('/api/voice-changer/convert_file', self.post_convert_file, methods=['POST'])
        self.router.add_api_route('/api/voice-changer/operation/start_server_device', self.start_server_device, methods=['POST'])
        self.router.add_api_route('/api/voice-changer/operation/stop_server_device', self.stop_server_device, methods=['POST'])
        self.router.add_api_route('/api/voice-changer-manager/information', self.get_voice_changer_information, methods=['GET'])
        self.router.add_api_route('/api_voice-changer_convert_chunk', self.post_convert_chunk, methods=['POST'])
        self.router.add_api_route('/api_voice-changer_convert_chunk_bulk', self.post_convert_chunk_bulk, methods=['POST'])
        self.router.add_api_route('/api_voice-changer_convert_file', self.post_convert_file, methods=['POST'])
        self.router.add_api_route('/api_voice-changer_operation_start_server_device', self.start_server_device, methods=['POST'])
        self.router.add_api_route('/api_voice-changer_operation_stop_server_device', self.stop_server_device, methods=['POST'])
        self.router.add_api_route('/api_voice-changer-manager_information', self.get_voice_changer_information, methods=['GET'])

    async def post_convert_chunk_bulk(self, waveform: UploadFile=File(...), x_timestamp: int | None=Header(default=0)):
        """b'\\n        \\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe5\\xa4\\x89\\xe6\\x8f\\x9b\\xe3\\x82\\x92\\xe8\\xa1\\x8c\\xe3\\x81\\x86API\\n\\n        Args:\\n            waveform (UploadFile): \\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x83\\x87\\xe3\\x83\\xbc\\xe3\\x82\\xbf float32\\xe3\\x81\\xae\\xe3\\x83\\x90\\xe3\\x82\\xa4\\xe3\\x83\\x8a\\xe3\\x83\\xaa\\xe3\\x83\\x87\\xe3\\x83\\xbc\\xe3\\x82\\xbf\\xe3\\x82\\x92\\xe6\\x83\\xb3\\xe5\\xae\\x9a\\xe3\\x81\\x97\\xe3\\x81\\xa6\\xe3\\x81\\x84\\xe3\\x82\\x8b\\xe3\\x80\\x82\\n            x_timestamp (int): \\xe3\\x82\\xbf\\xe3\\x82\\xa4\\xe3\\x83\\xa0\\xe3\\x82\\xb9\\xe3\\x82\\xbf\\xe3\\x83\\xb3\\xe3\\x83\\x97\\n        '"""
        if x_timestamp is None:
            x_timestamp = 0
        chunk = await waveform.read()
        chunk_np = np.frombuffer(chunk, dtype=np.float32)
        vc = VoiceChanger.get_instance()
        if vc.is_convert_chunk_bulk_started() is False:
            vc.start_convert_chunk_bulk()
        converted_np, _, performance_data = vc.convert_chunk_bulk(chunk_np)
        if converted_np is None:
            dummy = np.zeros([1], dtype=np.float32)
            return Response(content=dummy.tobytes(), media_type='application/octet-stream', headers={'x-timestamp': str(x_timestamp)})
        return Response(content=converted_np.tobytes(), media_type='application/octet-stream', headers={'x-timestamp': str(x_timestamp), 'x-performance': performance_data.model_dump_json() if performance_data is not None else '{}'})

    async def post_convert_chunk(self, waveform: UploadFile=File(...), x_timestamp: int | None=Header(default=0)):
        """b'\\n        \\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe5\\xa4\\x89\\xe6\\x8f\\x9b\\xe3\\x82\\x92\\xe8\\xa1\\x8c\\xe3\\x81\\x86API\\n\\n        Args:\\n            waveform (UploadFile): \\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x83\\x87\\xe3\\x83\\xbc\\xe3\\x82\\xbf np.float32\\xe3\\x81\\xae\\xe3\\x83\\x90\\xe3\\x82\\xa4\\xe3\\x83\\x8a\\xe3\\x83\\xaa\\xe3\\x83\\x87\\xe3\\x83\\xbc\\xe3\\x82\\xbf\\xe3\\x82\\x92\\xe6\\x83\\xb3\\xe5\\xae\\x9a\\xe3\\x81\\x97\\xe3\\x81\\xa6\\xe3\\x81\\x84\\xe3\\x82\\x8b\\xe3\\x80\\x82\\n            x_timestamp (int): \\xe3\\x82\\xbf\\xe3\\x82\\xa4\\xe3\\x83\\xa0\\xe3\\x82\\xb9\\xe3\\x82\\xbf\\xe3\\x83\\xb3\\xe3\\x83\\x97\\n        '"""
        chunk = await waveform.read()
        chunk_np = np.frombuffer(chunk, dtype=np.float32)
        vc = VoiceChanger.get_instance()
        converted_np, _, performance_data = vc.convert_chunk(chunk_np, direct_from_server=True)
        return Response(content=converted_np.tobytes(), media_type='application/octet-stream', headers={'x-timestamp': str(x_timestamp), 'x-performance': performance_data.model_dump_json() if performance_data is not None else '{}'})

    def post_convert_file(self, convert_file_param: ConvertFileParam):
        vc = VoiceChanger.get_instance()
        vc.convert_file(convert_file_param.src_path, convert_file_param.dst_path)

    def start_server_device(self):
        configuration_manager = ConfigurationManager.get_instance()
        conf = configuration_manager.get_voice_changer_configuration()
        if conf.voice_changer_input_mode == 'server':
            vc = LocalVoiceChangerInterface.get_instance()
            vc.start()
            event_emitter = EventEmitterManager.get_instance().get_event_emitter()
            if event_emitter is not None:
                event_emitter.emit_coroutine('command', ['reload'])
        else:
            raise Exception('Voice changer input mode is not server.')

    def stop_server_device(self):
        vc = LocalVoiceChangerInterface.get_instance()
        vc.stop()

    def get_voice_changer_information(self) -> VoiceChangerManagerInfo:
        voice_chanager_manager = VoiceChangerManager.get_instance()
        info = voice_chanager_manager.get_info()
        logging.getLogger(LOGGER_NAME).info(f'get_voice_changer_information {info}')
        return info