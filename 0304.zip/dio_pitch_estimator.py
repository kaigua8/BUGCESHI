

import pyworld
import numpy as np
import torch
from voice_changer_data_types import PitchEstimatorInfo
from pitch_estimator import PitchEstimator

class DioPitchEstimator(PitchEstimator):

    def __init__(self):
        super().__init__()
        self.f0_min = 50
        self.f0_max = 1100
        self.f0_mel_min = 1127 * np.log(1 + self.f0_min / 700)
        self.f0_mel_max = 1127 * np.log(1 + self.f0_max / 700)
    pass

    def estimate(self, audio: np.ndarray | torch.Tensor, prev_pitch: np.ndarray | torch.Tensor, up_key: int, sample_rate: int, window_length: int, silence_front_sec: float=0) -> tuple[np.ndarray, np.ndarray]:
        try:
            if isinstance(audio, torch.Tensor):
                audio = audio.cpu().numpy()
            if isinstance(prev_pitch, torch.Tensor):
                prev_pitch = prev_pitch.cpu().numpy().astype(np.float32)
            if audio.ndim != 1:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} audio.ndim is not 1 (size :{audio.ndim}, {audio.shape})')
            if prev_pitch.ndim != 2:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} prevPitch.ndim is not 2 (size :{prev_pitch.ndim}, {prev_pitch.shape})')
            pitch_length = audio.shape[0] // window_length
            silence_front_frame = silence_front_sec * sample_rate
            start_window = int(silence_front_frame / window_length)
            slience_front_frame_offset = start_window * window_length
            slience_front_frame_offset2 = len(audio) - 3000
            sf = max(min(slience_front_frame_offset, slience_front_frame_offset2), 0)
            audio = audio[sf:]
            assert isinstance(audio, np.ndarray), f'audio should be np.ndarray. {type(audio)}'
            assert isinstance(prev_pitch, np.ndarray), f'prev_pitch should be np.ndarray. {type(prev_pitch)}'
            _f0, t = pyworld.dio(audio.astype(np.double), fs=sample_rate, f0_floor=self.f0_min, f0_ceil=self.f0_max, channels_in_octave=2, frame_period=10)
            f0 = pyworld.stonemask(audio.astype(np.double), _f0, t, sample_rate)
            f0 *= pow(2, up_key / 12)
            pitch = prev_pitch.squeeze(axis=0)
            pitch = np.concatenate([pitch, f0], axis=0)
            if pitch.shape[0] < pitch_length:
                pitch = np.concatenate([np.zeros(pitch_length - pitch.shape[0]), pitch], axis=0)
            else:
                pitch = pitch[-pitch_length:]
            f0_mel = 1127 * np.log(1 + pitch / 700)
            f0_mel[f0_mel > 0] = (f0_mel[f0_mel > 0] - self.f0_mel_min) * 254 / (self.f0_mel_max - self.f0_mel_min) + 1
            f0_mel[f0_mel <= 1] = 1
            f0_mel[f0_mel > 255] = 255
            pitch_coarse = np.rint(f0_mel).astype(int)
        except Exception as e:
            raise RuntimeError(f'Exeption in {self.__class__.__name__}', e)
        return (pitch_coarse.reshape(1, -1), pitch.reshape(1, -1))

    def get_info(self) -> PitchEstimatorInfo:
        info = PitchEstimatorInfo(pitch_estimator_type='dio', model_file=None, device_id=-1, candidate_onnx_providers=None, candidate_onnx_provider_options=None, onnx_providers=None, onnx_provider_options=None)
        return info