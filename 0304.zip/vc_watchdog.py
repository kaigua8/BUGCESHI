

import logging
from pathlib import Path
from typing import Callable
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent
import time
import threading
from const import LOGGER_NAME
from voice_chanager_const import EventSource, ModelDir, SettingsDir

class VCClientFileEventHandler(FileSystemEventHandler):

    def __init__(self, callback: Callable[[EventSource, FileSystemEvent], None]):
        super().__init__()
        self.callback = callback

    def on_any_event(self, event: FileSystemEvent):
        if str(ModelDir) in event.src_path:
            self.callback('model', event)
        if str(SettingsDir) in event.src_path:
            self.callback('config', event)

class VCClientFileWatcher:

    def __init__(self, paths: list[Path]=[], handler=FileSystemEventHandler()):
        self.observer = Observer()
        self.handler = handler
        self.paths = paths
        self.stop_flag = False
        self.thread = threading.Thread(target=self.run)
        self.thread.start()

    def run(self):
        for path in self.paths:
            self.observer.schedule(self.handler, path, recursive=True)
        self.observer.start()
        logging.getLogger(LOGGER_NAME).info('MyWatcher Started')
        while True:
            time.sleep(1)
            if self.stop_flag:
                break
        self.observer.stop()
        self.observer.join()
        logging.getLogger(LOGGER_NAME).info('MyWatcher Terminated')

    def stop(self):
        self.stop_flag = True