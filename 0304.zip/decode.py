
import numpy as np
import convert

def argmax(logits):
    """Sample observations by taking the argmax"""
    bins = logits.argmax(axis=1)
    return (bins, convert.bins_to_frequency(bins))

def weighted_argmax(logits: np.ndarray):
    """Sample observations using weighted sum near the argmax"""
    bins = logits.argmax(axis=1)
    return (bins, _apply_weights(logits, bins))

def _apply_weights(logits, bins):
    start = np.maximum(0, bins - 4)
    end = np.minimum(logits.shape[1], bins + 5)
    for batch in range(logits.shape[0]):
        for time in range(logits.shape[2]):
            logits[batch, :start[batch, time], time] = float('-inf')
            logits[batch, end[batch, time]:, time] = float('-inf')
    if not hasattr(_apply_weights, 'weights'):
        weights = convert.bins_to_cents(np.arange(360))
        _apply_weights.weights = weights[None, :, None]
    probs = np.maximum(0, logits)
    cents = (_apply_weights.weights * probs).sum(axis=1) / probs.sum(axis=1)
    return convert.cents_to_frequency(cents)