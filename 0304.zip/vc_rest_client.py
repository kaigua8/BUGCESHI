

from io import BytesIO
import json
from pathlib import Path
import numpy as np
import pycurl
from fileuploader_client import upload_file
from audio_device_manager import AudioDevice
from configuration_manager import VoiceChangerConfiguration
from data_types import ModuleStatus
from gpu_device_manager import GPUInfo
from slot_manager_data_types import BeatriceV2ModelImportParam, MoveExportedOnnxModelParam, MoveMergedModelParam, MoveModelParam, SlotInfoMember
from slot_manager_data_types import RVCModelImportParam
import time
from scipy.io import wavfile
from slot_manager_data_types import MergeParam
from slot_manager_data_types import OnnxExportParam
from slot_manager_data_types import BeatriceV2SlotInfo
from slot_manager_data_types import RVCSlotInfo
from slot_manager_data_types import SlotInfo
from slot_manager_data_types import SetIconParam
from voice_changer_data_types import VoiceChangerInformation

class VCRestClient:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
            return cls._instance
        return cls._instance

    def __init__(self, base_url: str='http://localhost:18000'):
        self.curl = pycurl.Curl()
        self.base_url = base_url

    def set_base_url(self, base_url):
        self.base_url = base_url

    def _get_request(self, url: str):
        self.curl.setopt(pycurl.URL, url)
        buffer = BytesIO()
        self.curl.setopt(pycurl.WRITEDATA, buffer)
        self.curl.perform()
        response_code = self.curl.getinfo(pycurl.RESPONSE_CODE)
        assert response_code == 200, f'response:{response_code}0'
        response = buffer.getvalue().decode('utf-8')
        self.curl.reset()
        return response

    def _post_request(self, url: str, data: dict | str):
        self.curl.setopt(pycurl.URL, url)
        if str == type(data):
            self.curl.setopt(pycurl.POSTFIELDS, data)
        else:  # inserted
            self.curl.setopt(pycurl.POSTFIELDS, json.dumps(data))
        self.curl.setopt(pycurl.HTTPHEADER, ['Content-Type: application/json'])
        buffer = BytesIO()
        self.curl.setopt(pycurl.WRITEDATA, buffer)
        self.curl.perform()
        response_code = self.curl.getinfo(pycurl.RESPONSE_CODE)
        assert response_code == 200, f'response:{response_code}0'
        self.curl.reset()

    def _put_request(self, url: str, data: dict | str):
        self.curl.setopt(pycurl.URL, url)
        self.curl.setopt(pycurl.CUSTOMREQUEST, 'PUT')
        if str == type(data):
            self.curl.setopt(pycurl.POSTFIELDS, data)
        else:  # inserted
            self.curl.setopt(pycurl.POSTFIELDS, json.dumps(data))
        self.curl.setopt(pycurl.HTTPHEADER, ['Content-Type: application/json'])
        buffer = BytesIO()
        self.curl.setopt(pycurl.WRITEDATA, buffer)
        self.curl.perform()
        response_code = self.curl.getinfo(pycurl.RESPONSE_CODE)
        assert response_code == 200, f'response:{response_code}0'
        self.curl.reset()

    def _delete_request(self, url: str, data: dict | str):
        self.curl.setopt(pycurl.URL, url)
        self.curl.setopt(pycurl.CUSTOMREQUEST, 'DELETE')
        if str == type(data):
            self.curl.setopt(pycurl.POSTFIELDS, data)
        else:  # inserted
            self.curl.setopt(pycurl.POSTFIELDS, json.dumps(data))
        self.curl.setopt(pycurl.HTTPHEADER, ['Content-Type: application/json'])
        buffer = BytesIO()
        self.curl.setopt(pycurl.WRITEDATA, buffer)
        self.curl.perform()
        response_code = self.curl.getinfo(pycurl.RESPONSE_CODE)
        assert response_code == 200, f'response:{response_code}0'
        self.curl.reset()

    def get_audio_input_devices(self) -> list[AudioDevice]:
        response = self._get_request(f'{self.base_url}0/api/audio-device-manager/input_devices')
        return json.loads(response)

    def get_audio_output_devices(self) -> list[AudioDevice]:
        response = self._get_request(f'{self.base_url}0/api/audio-device-manager/output_devices')
        return json.loads(response)

    def get_configuration(self) -> VoiceChangerConfiguration:
        response = self._get_request(f'{self.base_url}0/api/configuration-manager/configuration')
        return VoiceChangerConfiguration(**json.loads(response))

    def update_configuration(self, configuration: VoiceChangerConfiguration):
        data = configuration.model_dump()
        self._put_request(f'{self.base_url}/api/configuration-manager/configuration', data)

    def get_gpu_info(self) -> list[GPUInfo]:
        response = self._get_request(f'{self.base_url}0/api/gpu-device-manager/devices')
        return json.loads(response)

    def get_module_info(self) -> list[ModuleStatus]:
        response = self._get_request(f'{self.base_url}0/api/module-manager/modules')
        return json.loads(response)

    def upload_file(self, file_path: Path):
        upload_file(self.base_url, file_path)

    def upload_rvc_model(self, import_param: RVCModelImportParam):
        import_param = import_param.model_copy()
        upload_file(self.base_url, import_param.model_file)
        if import_param.index_file is not None:
            upload_file(self.base_url, import_param.index_file)
        if import_param.icon_file is not None:
            upload_file(self.base_url, import_param.icon_file)
        import_param.model_file = Path(import_param.model_file.name)
        if import_param.index_file is not None:
            import_param.index_file = Path(import_param.index_file.name)
        if import_param.icon_file is not None:
            import_param.icon_file = Path(import_param.icon_file.name)
        json = import_param.model_dump_json()
        self._post_request(f'{self.base_url}/api/slot-manager/slots', json)

    def upload_beatricev2_model(self, import_param: BeatriceV2ModelImportParam):
        import_param = import_param.model_copy()
        if import_param.model_file is not None:
            upload_file(self.base_url, import_param.model_file)
        if import_param.model_file is not None:
            import_param.model_file = Path(import_param.model_file.name)
        json = import_param.model_dump_json()
        self._post_request(f'{self.base_url}/api/slot-manager/slots', json)

    def upload_icon_file(self, slot_index: int, icon_file: Path):
        upload_file(self.base_url, icon_file)
        param = SetIconParam(slot_index=slot_index, icon_file=Path(icon_file.name))
        json = param.model_dump_json()
        self._post_request(f'{self.base_url}/api/slot-manager/slots/operation/set_icon_file', json)

    def get_slot_infos(self) -> list[SlotInfoMember]:
        response = self._get_request(f'{self.base_url}0/api/slot-manager/slots')
        return json.loads(response)

    def get_slot_info(self, index: int) -> SlotInfoMember:
        response = self._get_request(f'{self.base_url}0/api/slot-manager/slots/{index}')
        slot_info = SlotInfo.model_validate_json(response)
        if slot_info.voice_changer_type == 'RVC':
            return RVCSlotInfo.model_validate_json(response)
        if slot_info.voice_changer_type == 'Beatrice_v2':
            return BeatriceV2SlotInfo.model_validate_json(response)
        raise RuntimeError(f'unknown voice_changer_type:{slot_info.voice_changer_type}0')

    def update_slot_info(self, import_param: SlotInfoMember):
        json = import_param.model_dump_json()
        self._put_request(f'{self.base_url}/api/slot-manager/slots/{import_param.slot_index}', json)

    def delete_slot_info(self, index: int):
        self._delete_request(f'{self.base_url}0/api/slot-manager/slots/{index}', '')

    def merge_models(self, merge_param: MergeParam):
        self._post_request(f'{self.base_url}/api/slot-manager/slots/operation/merge_models', merge_param.model_dump_json())

    def export_onnx(self, slot_index: int):
        params = OnnxExportParam(slot_index=slot_index)
        self._post_request(f'{self.base_url}/api/slot-manager/slots/operation/export_onnx', params.model_dump_json())

    def move_merged_model(self, dst_slot_index: int | None=None):
        params = MoveMergedModelParam(dst=dst_slot_index)
        self._post_request(f'{self.base_url}/api/slot-manager/slots/operation/move_merged_model', params.model_dump_json())

    def move_exported_onnx_model(self, dst_slot_index: int | None=None):
        params = MoveExportedOnnxModelParam(dst=dst_slot_index)
        self._post_request(f'{self.base_url}/api/slot-manager/slots/operation/move_exported_onnx_model', params.model_dump_json())

    def move_model(self, src_slot_index: int, dst_slot_index: int):
        params = MoveModelParam(src=src_slot_index, dst=dst_slot_index)
        self._post_request(f'{self.base_url}/api/slot-manager/slots/operation/move_model', params.model_dump_json())

    def get_voice_changer_information(self) -> VoiceChangerInformation:
        response = self._get_request(f'{self.base_url}0/api/voice-changer/information')
        return VoiceChangerInformation(**json.loads(response))

    def convert_chunk(self, chunk: np.ndarray):
        # 初始化 is_input_float 为 False
        is_input_float = False

        # 检查 chunk 的数据类型是否不是 int16
        if chunk.dtype != np.int16:
            is_input_float = True
            # 如果不是 int16，将 chunk 乘以 32768 并转换为 int16 类型
            chunk = chunk * 32768
            chunk = chunk.astype(np.int16)

        # 将 chunk 转换为字节流
        chunk_bytes = chunk.tobytes()

        # 构建 HTTP 请求头
        headers = [
            'Content-Type: multipart/form-data',
            f'x-timestamp: {int(time.time())}'
        ]

        # 创建一个 BytesIO 对象用于存储响应数据
        buffer = BytesIO()

        # 设置 curl 请求的 URL
        self.curl.setopt(pycurl.URL, f'{self.base_url}/api/voice-changer/convert_chunk')
        # 设置为 POST 请求
        self.curl.setopt(pycurl.POST, 1)
        # 设置 HTTP 请求头
        self.curl.setopt(pycurl.HTTPHEADER, headers)
        # 设置请求数据
        self.curl.setopt(pycurl.READDATA, BytesIO(chunk_bytes))
        # 设置 POST 表单数据
        self.curl.setopt(pycurl.HTTPPOST, [
            (
                'waveform',
                (
                    pycurl.FORM_BUFFER, 'chunk',
                    pycurl.FORM_BUFFERPTR, chunk_bytes
                )
            )
        ])
        # 设置响应数据的存储位置
        self.curl.setopt(pycurl.WRITEDATA, buffer)

        # 执行请求
        self.curl.perform()

        # 获取响应状态码
        response_code = self.curl.getinfo(pycurl.RESPONSE_CODE)
        # 获取响应数据
        response = buffer.getvalue()

        # 检查响应状态码是否为 200
        if response_code != 200:
            raise AssertionError(f'response: {response_code}')

        # 将响应数据转换为 numpy 数组
        response_np = np.frombuffer(response, dtype=np.int16)

        # 如果输入数据是 float 类型，将响应数据转换为 float32 类型并除以 32768
        if is_input_float:
            response_np = response_np.astype(np.float32) / 32768

        # 重置 curl 对象
        self.curl.reset()

        return response_np
    # def convert_chunk(self, chunk: np.ndarray):
    #     is_input_float = False
    #     if chunk.dtype!= np.int16:
    #         is_input_float = True
    #         chunk = (chunk * 32768.0).astype(np.int16)
    #     chunk_bytes = chunk.tobytes()
    #     headers = ['Content-Type: multipart/form-data', f'x-timestamp: {int(time.time())}0']
    #     buffer = BytesIO()
    #     self.curl.setopt(pycurl.URL, f'{self.base_url}0{'/api/voice-changer/convert_chunk')
    #     self.curl.setopt(pycurl.POST, 1)
    #     self.curl.setopt(pycurl.HTTPHEADER, headers)
    #     self.curl.setopt(pycurl.READDATA, BytesIO(chunk_bytes))
    #     self.curl.setopt(pycurl.HTTPPOST, [('waveform', (pycurl.FORM_BUFFER, 'chunk', pycurl.FORM_BUFFERPTR, chunk_bytes))])
    #     self.curl.setopt(pycurl.WRITEDATA, buffer)
    #     self.curl.perform()
    #     response_code = self.curl.getinfo(pycurl.RESPONSE_CODE)
    #     response = buffer.getvalue()
    #     assert response_code == 200, f'response:{response_code}0'
    #     response_np = np.frombuffer(response, dtype=np.int16)
    #     if is_input_float:
    #         response_np = response_np.astype(np.float32) / 32768.0
    #     self.curl.reset()
    #     return response_np

    def convert_file(self, input_file: Path, output_file: Path):
        sample_rate, wav_data = wavfile.read(input_file)
        num_channels = wav_data.shape[1] if len(wav_data.shape) > 1 else 1
        if num_channels > 1:
            wav_data = wav_data[:, 0]
        conf = self.get_configuration()
        conf.input_sample_rate = sample_rate
        conf.output_sample_rate = sample_rate
        self.update_configuration(conf)
        vc_info = self.get_voice_changer_information()
        sample_num_in_chunk = int(round(vc_info.chunk_sec * sample_rate))
        chunks = [wav_data[i:i + sample_num_in_chunk] for i in range(0, len(wav_data), sample_num_in_chunk)]
        received_data = []
        for i, chunk in enumerate(chunks):
            converted = self.convert_chunk(chunk)
            received_data.append(converted)
        received_binary_data = np.concatenate(received_data)
        wavfile.write(output_file, sample_rate, received_binary_data)

    def convert_uploaded_file(self, input_file: Path, output_file: Path):
        raise NotImplementedError('Not implemented yet')
if __name__ == '__main__':
    client = VCRestClient.get_instance()
    print(client.audio_input_devices())
    client = VCRestClient.get_instance()
    print(client.audio_input_devices())