

import logging
from pathlib import Path
from typing import Any
import torch
from torch import nn
from onnxsim import simplify
import onnx
import json
from const import LOGGER_NAME
from exception import ERROR_CODE_RVC_EXPORT_FAILED_UNSUPPORTED_MODEL_TYPE, ERROR_CODE_UNKNOWN_VOICE_CHANGER_TYPE, VCClientError
from slot_manager_data_types import OnnxExportParam
from rvc_ddpn_f0_onnx import RVCDDPNF0Onnx
from rvc_ddpn_nof0_onnx import RVCDDPNNoF0Onnx
from rvcv1_f0_onnx import RVCV1F0Onnx
from rvcv1_nof0_onnx import RVCV1NoF0Onnx
from rvcv2_f0_onnx import RVCV2F0Onnx
from rvcv2_nof0_onnx import RVCV2NoF0Onnx
from slot_manager_data_types import RVCSlotInfo
from slot_manager import SlotManager
from voice_chanager_const import ModelDir

class RVCOnnxExporter:

    def export(self, params: OnnxExportParam, store_path: Path):
        slot_index = params.slot_index
        slot_info = SlotManager.get_instance().get_slot_info(slot_index)
        assert isinstance(slot_info, RVCSlotInfo), f'slot is not RVC pytorch: {slot_info}'
        if slot_info.inferencer_type not in ['pyTorchRVC', 'pyTorchRVCNono', 'pyTorchRVCv2', 'pyTorchRVCv2Nono', 'pyTorchDDPN', 'pyTorchDDPNNono']:
            logging.getLogger(LOGGER_NAME).error(f'rvc onnx export, unsupported inferencer_type:{slot_info.inferencer_type}')
            raise VCClientError(ERROR_CODE_UNKNOWN_VOICE_CHANGER_TYPE, f'unsupported inferencer_type:{slot_info.inferencer_type}')
        metadata = {'application': 'VC_CLIENT', 'version': '3.0', 'samplingRate': slot_info.sample_rate, 'f0': 1 if slot_info.is_f0 is True else 0, 'embedder': slot_info.embedder}
        assert slot_info.model_file is not None
        cpt = torch.load(Path(ModelDir / str(slot_info.slot_index) / slot_info.model_file), map_location='cpu')
        if slot_info.inferencer_type == 'pyTorchRVC':
            inferencer = RVCV1F0Onnx(*cpt['config'])
        elif slot_info.inferencer_type == 'pyTorchRVCNono':
            inferencer = RVCV1NoF0Onnx(*cpt['config'])
        elif slot_info.inferencer_type == 'pyTorchRVCv2':
            inferencer = RVCV2F0Onnx(*cpt['config'])
        elif slot_info.inferencer_type == 'pyTorchRVCv2Nono':
            inferencer = RVCV2NoF0Onnx(*cpt['config'])
        elif slot_info.inferencer_type == 'pyTorchDDPN':
            inferencer = RVCDDPNF0Onnx(*cpt['config'])
        elif slot_info.inferencer_type == 'pyTorchDDPNNono':
            inferencer = RVCDDPNNoF0Onnx(*cpt['config'])
        else:
            logging.getLogger(LOGGER_NAME).error(f'rvc onnx export, unsupported inferencer_type:{slot_info.inferencer_type}')
            raise VCClientError(ERROR_CODE_UNKNOWN_VOICE_CHANGER_TYPE, f'unsupported inferencer_type:{slot_info.inferencer_type}')
        inferencer.eval()
        inferencer.load_state_dict(cpt['weight'], strict=False)
        feats_length = 64
        if slot_info.embedder in ['hubert_base_l9fp', 'hubert_base_japanese_l9fp']:
            emb_channels = 256
        elif slot_info.embedder in ['hubert_base_l12', 'contentvec', 'hubert_base_japanese_l12', 'applio_japanese_hubert_base_l12', 'applio_chinese_hubert_base_l12', 'applio_korean_hubert_base_l12']:
            emb_channels = 768
        else:
            logging.getLogger(LOGGER_NAME).error(f'rvc onnx export, unsupported embedder_type:{slot_info.embedder}')
            raise VCClientError(ERROR_CODE_RVC_EXPORT_FAILED_UNSUPPORTED_MODEL_TYPE, f'unsupported embedder_type:{slot_info.embedder}')
        feats = torch.FloatTensor(1, feats_length, emb_channels)
        p_len = torch.LongTensor([feats_length])
        sid = torch.LongTensor([0])
        if slot_info.is_f0 is True:
            pitch = torch.zeros(1, feats_length, dtype=torch.int64)
            pitchf = torch.FloatTensor(1, feats_length)
            input_names = ['feats', 'p_len', 'pitch', 'pitchf', 'sid']
            inputs = (feats, p_len, pitch, pitchf, sid)
        else:
            input_names = ['feats', 'p_len', 'sid']
            inputs = (feats, p_len, sid)
        output_names = ['audio']
        torch.onnx.export(inferencer, inputs, store_path, dynamic_axes={'feats': [1], 'pitch': [1], 'pitchf': [1]}, do_constant_folding=False, opset_version=17, verbose=False, input_names=input_names, output_names=output_names)
        model_onnx2 = onnx.load(store_path)
        model_simp, check = simplify(model_onnx2)
        meta = model_simp.metadata_props.add()
        meta.key = 'metadata'
        meta.value = json.dumps(metadata)
        onnx.save(model_simp, store_path)