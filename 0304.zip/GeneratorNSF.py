
import torch
from torch import nn
from torch.nn import functional as F
from torch.nn import Conv1d, ConvTranspose1d
from torch.nn.utils import weight_norm, remove_weight_norm
import numpy as np
from commons import init_weights
from SourceModuleHnNSF import SourceModuleHnNSF
from modules import LRELU_SLOPE, ResBlock1, ResBlock2

class GeneratorNSF(torch.nn.Module):
    pass

    def __init__(self, initial_channel, resblock, resblock_kernel_sizes, resblock_dilation_sizes, upsample_rates, upsample_initial_channel, upsample_kernel_sizes, gin_channels, sr, is_half=False):
        super(GeneratorNSF, self).__init__()
        self.num_kernels = len(resblock_kernel_sizes)
        self.num_upsamples = len(upsample_rates)
        self.upsample_rates = upsample_rates
        self.f0_upsamp = torch.nn.Upsample(scale_factor=np.prod(upsample_rates))
        self.m_source = SourceModuleHnNSF(sampling_rate=sr, harmonic_num=0, is_half=is_half)
        self.noise_convs = nn.ModuleList()
        self.conv_pre = Conv1d(initial_channel, upsample_initial_channel, 7, 1, padding=3)
        resblock = ResBlock1 if resblock == '1' else ResBlock2
        self.ups = nn.ModuleList()
        for i, (u, k) in enumerate(zip(upsample_rates, upsample_kernel_sizes)):
            c_cur = upsample_initial_channel // 2 ** (i + 1)
            self.ups.append(weight_norm(ConvTranspose1d(upsample_initial_channel // 2 ** i, upsample_initial_channel // 2 ** (i + 1), k, u, padding=(k - u) // 2)))
            if i + 1 < len(upsample_rates):
                stride_f0 = np.prod(upsample_rates[i + 1:])
                self.noise_convs.append(Conv1d(1, c_cur, kernel_size=stride_f0 * 2, stride=stride_f0, padding=stride_f0 // 2))
            else:
                self.noise_convs.append(Conv1d(1, c_cur, kernel_size=1))
        self.resblocks = nn.ModuleList()
        for i in range(len(self.ups)):
            ch = upsample_initial_channel // 2 ** (i + 1)
            for j, (k, d) in enumerate(zip(resblock_kernel_sizes, resblock_dilation_sizes)):
                self.resblocks.append(resblock(ch, k, d))
        self.conv_post = Conv1d(ch, 1, 7, 1, padding=3, bias=False)
        self.ups.apply(init_weights)
        if gin_channels != 0:
            self.cond = nn.Conv1d(gin_channels, upsample_initial_channel, 1)
        self.upp = np.prod(upsample_rates)
        self.realtime = False
        if resblock != '1':
            self.realtime = True
            self.ups_size = [0 for _ in range(len(self.ups))]
            self.noise_conv_size = [0 for _ in range(len(self.ups))]
            self.ups_size[-1] += 3
            for i in range(len(self.ups) - 1, -1, -1):
                for k, d in zip(resblock_kernel_sizes[::-1], resblock_dilation_sizes[::-1]):
                    self.ups_size[i] += (k - 1) // 2
                    self.ups_size[i] += d[-1] * (k - 1) // 2
                self.noise_conv_size[i] = self.ups_size[i] * np.prod(upsample_rates[i:])
                self.ups_size[i] = -(-self.ups_size[i] // upsample_rates[i]) + (upsample_kernel_sizes[i] - upsample_rates[i]) // 2
                if i:
                    self.ups_size[i - 1] = self.ups_size[i] + 0

    def forward(self, x, f0, g=None):
        har_source, noi_source, uv = self.m_source(f0, self.upp)
        har_source = har_source.transpose(1, 2)
        x = self.conv_pre(x)
        if g is not None:
            x = x + self.cond(g)
        for i in range(self.num_upsamples):
            x = F.leaky_relu(x, LRELU_SLOPE)
            x = self.ups[i](x)
            x_source = self.noise_convs[i](har_source)
            x = x[:, :, :x_source.shape[2]]
            x = x + x_source
            xs = None
            for j in range(self.num_kernels):
                if xs is None:
                    xs = self.resblocks[i * self.num_kernels + j](x)
                else:
                    xs += self.resblocks[i * self.num_kernels + j](x)
            x = xs / self.num_kernels
        x = F.leaky_relu(x)
        x = self.conv_post(x)
        x = torch.tanh(x)
        return x

    def infer_realtime(self, x, f0, g=None, convert_length=None):
        out_length = x.shape[2] * np.prod(self.upsample_rates)
        if convert_length is None:
            convert_length = x.shape[2] * np.prod(self.upsample_rates)
        har_source, noi_source, uv = self.m_source(f0, self.upp)
        har_source = har_source.transpose(1, 2)
        x = self.conv_pre(x)
        if g is not None:
            x = x + self.cond(g)
        for i in range(self.num_upsamples):
            if self.realtime:
                x = x[:, :, -self.ups_size[i] + -convert_length // np.prod(self.upsample_rates[i:]):]
            x = F.leaky_relu(x, LRELU_SLOPE)
            x_ = self.ups[i](x)
            x_source = self.noise_convs[i](har_source[:, :, -convert_length - self.noise_conv_size[i]:])
            x = torch.zeros([x_.shape[0], x_.shape[1], max(x_.shape[2], x_source.shape[2])], device=x.device, dtype=x.dtype)
            x[:, :, -x_.shape[2]:] += x_
            x[:, :, -x_source.shape[2]:] += x_source
            xs = None
            for j in range(self.num_kernels):
                if xs is None:
                    xs = self.resblocks[i * self.num_kernels + j](x)
                else:
                    xs += self.resblocks[i * self.num_kernels + j](x)
            x = xs / self.num_kernels
        x = F.leaky_relu(x)
        x = self.conv_post(x)
        x = torch.tanh(x)
        out = torch.zeros([x.shape[0], 1, out_length], device=x.device, dtype=x.dtype)
        out[:, :, -x.shape[2]:] = x[:, :, -out.shape[2]:]
        return x

    def remove_weight_norm(self):
        for layer in self.ups:
            remove_weight_norm(layer)
        for layer in self.resblocks:
            layer.remove_weight_norm()