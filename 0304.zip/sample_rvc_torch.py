from data_types import RVCSampleInfo, SampleInfoMember

# 创建多个 RVCSampleInfo 实例，每个实例代表一个不同的语音模型样本
sample1 = RVCSampleInfo(
    id='KikotoKurage_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='黄琴海月(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_kurage/kikoto_kurage_v2_40k_e100.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_kurage/added_IVF5181_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/kikoto_kurage/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_kurage/kikoto_kurage.png',
    credit='黄琴海月',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchRVCv2'
)

sample2 = RVCSampleInfo(
    id='KikotoMahiro_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='黄琴まひろ(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_mahiro/kikoto_mahiro_v2_40k.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_mahiro/added_IVF6881_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/kikoto_mahiro/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_mahiro/kikoto_mahiro.png',
    credit='黄琴まひろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchRVCv2'
)

sample3 = RVCSampleInfo(
    id='TokinaShigure_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='刻鳴時雨(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tokina_shigure/tokina_shigure_v2_40k_e100.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tokina_shigure/added_IVF2736_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/tokina_shigure/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tokina_shigure/tokina_shigure.png',
    credit='刻鳴時雨',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchRVCv2'
)

sample4 = RVCSampleInfo(
    id='Amitaro_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='あみたろ(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/amitaro/amitaro_v2_40k_e100.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/amitaro/added_IVF3139_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/amitaro/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/amitaro/amitaro.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchRVCv2'
)

sample5 = RVCSampleInfo(
    id='Tsukuyomi-chan_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='つくよみちゃん(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tsukuyomi-chan/tsukuyomi_v2_40k_e100.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tsukuyomi-chan/added_IVF7852_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/blob/main/rvc_v2_alpha/tsukuyomi-chan/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tsukuyomi-chan/tsukuyomi-chan.png',
    credit='つくよみちゃん',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchRVCv2'
)

sample6 = RVCSampleInfo(
    id='V2-AISO-HOWATTO_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='ほわっと風味(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-HOWATTO.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/description.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-HOWATTO.jpg',
    credit='ちはや神社',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchRVCv2Nono'
)

sample7 = RVCSampleInfo(
    id='V2-AISO-KAKKOII_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='かっこいい風味(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-KAKKOII.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/description.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-KAKKOII.jpg',
    credit='ちはや神社',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchRVCv2Nono'
)

sample8 = RVCSampleInfo(
    id='V2-AISO-SARASARA_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='さらさら風味(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-SARASARA.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/description.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-SARASARA.jpg',
    credit='ちはや神社',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchRVCv2Nono'
)

sample9 = RVCSampleInfo(
    id='V2-AISO-SITTORI_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='しっとり風味(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-SITTORI.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/description.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-SITTORI.jpg',
    credit='ちはや神社',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchRVCv2Nono'
)

sample10 = RVCSampleInfo(
    id='V2-AISO-SYAKITTO_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'torch'],
    name='しゃきっと風味(torch)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-SYAKITTO.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/description.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_chihaya_jinja/V2-AISO-SYAKITTO.jpg',
    credit='ちはや神社',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchRVCv2Nono'
)

# 将所有样本存储在一个列表中
SAMPLE_RVC_TORCH = [
    sample1, sample2, sample3, sample4, sample5,
    sample6, sample7, sample8, sample9, sample10
]

# 添加类型注解
# __annotations__['SAMPLE_RVC_TORCH'] = list[SampleInfoMember]