

from time import perf_counter
import math
import numpy as np
from scipy.io import wavfile
from pathlib import Path
from beatrice import load_beatrice, ParaphernaliaVersion
# from beatrice import SphericalAverage
pass
DEFAULT_PHONE_EXTRACTOR_FILE = 'beatrice_api/build/sample_inputs/phone_extractor.bin'
DEFAULT_PITCH_ESTIMATOR_FILE = 'beatrice_api/build/sample_inputs/pitch_estimator.bin'
DEFAULT_FORMANT_SHIFT_EMBEDDINGS_FILE = 'beatrice_api/build/sample_inputs/formant_shift_embeddings.bin'
DEFAULT_SPEAKER_EMBEDDINGS_FILE = 'beatrice_api/build/sample_inputs/speaker_embeddings.bin'
DEFAULT_WAVEFORM_GENERATOR_FILE = 'beatrice_api/build/sample_inputs/waveform_generator.bin'

class SimpleBeatrice:
    """
    SimpleBeatrice is a simple wrapper class for Beatrice API.
    """


    def __init__(self, model_version: ParaphernaliaVersion='2.0.0-beta.1', phone_extractor_parameter_file: str | None=None, pitch_estimator_parameter_file: str | None=None, formant_shift_embeddings_file: str | None=None, speaker_embeddings_file: str | None=None, waveform_generator_parameter_file: str | None=None):
        """
        Initialize SimpleBeatrice instance.
        Args:
            phone_extractor_parameter_file (str, optional): Path to the phone extractor parameter file. Defaults to None.
            pitch_estimator_parameter_file (str, optional): Path to the pitch estimator parameter file. Defaults to None.
            formant_shift_embeddings_file (str, optional): Path to the formant shift embeddings file. Defaults to None.
            speaker_embeddings_file (str, optional): Path to the speaker embeddings file. Defaults to None.
            waveform_generator_parameter_file (str, optional): Path to the waveform generator parameter file. Defaults to None.
        """
        beatrice = load_beatrice(model_version)
        self.IN_HOP_LENGTH = beatrice.IN_HOP_LENGTH
        self.IN_SAMPLE_RATE = beatrice.IN_SAMPLE_RATE
        self.OUT_SAMPLE_RATE = beatrice.OUT_SAMPLE_RATE
        self.PITCH_BINS = beatrice.PITCH_BINS
        self.PITCH_BINS_PER_OCTAVE = beatrice.PITCH_BINS_PER_OCTAVE
        self.PhoneExtractor = beatrice.PhoneExtractor
        self.PitchEstimator = beatrice.PitchEstimator
        self.WaveformGenerator = beatrice.WaveformGenerator
        self.read_speaker_embeddings = beatrice.read_speaker_embeddings
        if phone_extractor_parameter_file is None:
            self.phone_extractor_parameter_file = Path(__file__).parent.parent / f'{DEFAULT_PHONE_EXTRACTOR_FILE}'
        else:
            self.phone_extractor_parameter_file = Path(phone_extractor_parameter_file)
        if pitch_estimator_parameter_file is None:
            self.pitch_estimator_parameter_file = Path(__file__).parent.parent / f'{DEFAULT_PITCH_ESTIMATOR_FILE}'
        else:
            self.pitch_estimator_parameter_file = Path(pitch_estimator_parameter_file)
        if formant_shift_embeddings_file is None:
            self.formant_shift_embeddings_file = Path(__file__).parent.parent / f'{DEFAULT_FORMANT_SHIFT_EMBEDDINGS_FILE}'
        else:
            self.formant_shift_embeddings_file = Path(formant_shift_embeddings_file)
        if speaker_embeddings_file is None:
            self.speaker_embeddings_file = Path(__file__).parent.parent / f'{DEFAULT_SPEAKER_EMBEDDINGS_FILE}'
        else:
            self.speaker_embeddings_file = Path(speaker_embeddings_file)
        if waveform_generator_parameter_file is None:
            self.waveform_generator_parameter_file = Path(__file__).parent.parent / f'{DEFAULT_WAVEFORM_GENERATOR_FILE}'
        else:
            self.waveform_generator_parameter_file = Path(waveform_generator_parameter_file)
        self.phone_extractor = self.PhoneExtractor()
        self.phone_extractor.read_parameters(self.phone_extractor_parameter_file)
        self.pitch_estimator = self.PitchEstimator()
        self.pitch_estimator.read_parameters(self.pitch_estimator_parameter_file)
        self.formant_shift_embeddings = self.read_speaker_embeddings(self.formant_shift_embeddings_file)
        self.speaker_embeddings = self.read_speaker_embeddings(self.speaker_embeddings_file)
        self.waveform_generator = self.WaveformGenerator()
        self.waveform_generator.read_parameters(self.waveform_generator_parameter_file)
        self.block_size = 1
        self.phone_ctx = self.phone_extractor.new_context(self.block_size)
        self.pitch_ctx = self.pitch_estimator.new_context(self.block_size)
        self.waveform_ctx = self.waveform_generator.new_context(self.block_size)
        self.target_speaker_weights = []
        self.merged_speaker_embedding = np.zeros((1, 256), dtype=np.float32)
        #self.speaker_embeddings_spherical_average = SphericalAverage(self.speaker_embeddings)

    def get_target_speaker_num(self):
        """
        Get the number of target speakers.
        Returns:
            int: The number of target speakers.
        """
        return self.speaker_embeddings.shape[0]

    def set_target_speaker_weights(self, target_speaker_weights: list[float]):
        """
        Set target speaker ID.
        Args:
            target_speaker_id (int): Target speaker ID.
        """
        self.target_speaker_weights = target_speaker_weights
        self.speaker_embeddings_spherical_average.set_weights(target_speaker_weights)
        update_count = 0
        while not self.speaker_embeddings_spherical_average.update():
            update_count += 1
            if update_count > 10:
                break
            pass
        merged_speaker_embedding = self.speaker_embeddings_spherical_average.apply_weights(self.speaker_embeddings)
        self.merged_speaker_embedding = merged_speaker_embedding.reshape(1, -1)


    def convert_segment(self, source_wav_segment: np.ndarray[any, np.dtype[np.float32]], target_speaker_id: int | None=1, pitch_shift_semitones: float=0.0, formant_shift_semitones: float=0.0, use_merged_speaker_embedding: bool=False, calculate_source_average_pitch: bool=False):
        """
        Convert a segment of audio waveform.
        Args:
            source_wav_segment (np.ndarray): Source audio waveform segment.
            target_speaker_id (int, optional): Target speaker ID. Defaults to 1. If use_merged_speaker_embedding is True, this argument is ignored.
            pitch_shift_semitones (float, optional): Pitch shift in semitones. Defaults to 0.0.
            formant_shift_semitones (float, optional): Formant shift in semitones. Defaults to 0.0. [-2.0, 2.0] で 0.5 刻み
            use_merged_speaker_embedding (bool, optional): Use merged speaker embedding. Defaults to False.
        """
        block_size_in_input_sample_rate = self.block_size * self.IN_HOP_LENGTH
        if len(source_wav_segment) < block_size_in_input_sample_rate:
            source_wav_segment = np.pad(source_wav_segment, (0, block_size_in_input_sample_rate - len(source_wav_segment)))
        phone = self.phone_extractor(source_wav_segment, self.phone_ctx)
        quantized_pitch, pitch_features = self.pitch_estimator(source_wav_segment, self.pitch_ctx)
        source_average_pitch = -1
        if calculate_source_average_pitch:
            source_average_pitch = 69.0 + 12.0 * math.log2(quantized_pitch / 440.0)
            source_average_pitch = round(source_average_pitch * 8.0) / 8.0
        quantized_pitch = (quantized_pitch + int(round(pitch_shift_semitones * self.PITCH_BINS_PER_OCTAVE / 12.0))).clip(1, self.PITCH_BINS - 1)
        if use_merged_speaker_embedding:
            speaker_embedding = self.merged_speaker_embedding.copy()
        else:
            speaker_embedding = self.speaker_embeddings[[target_speaker_id] * self.block_size]
        speaker_embedding += self.formant_shift_embeddings[4 + int(round(formant_shift_semitones * 2.0))]
        converted_wav_segment = self.waveform_generator(phone, quantized_pitch, pitch_features, speaker_embedding, self.waveform_ctx)
        return (converted_wav_segment, source_average_pitch)


    def convert_file(self, in_filename: str, out_filename: str, target_speaker_id: int=1, pitch_shift_semitones: float=0.0, formant_shift_semitones: float=0.0, use_merged_speaker_embedding: bool=False):
        """
        Convert an audio file.
        Args:
            in_filename (str): Input audio file name.
            out_filename (str): Output audio file name.
            target_speaker_id (int, optional): Target speaker ID. Defaults to 1. If use_merged_speaker_embedding is True, this argument is ignored.
            pitch_shift_semitones (float, optional): Pitch shift in semitones. Defaults to 0.0.
            formant_shift_semitones (float, optional): Formant shift in semitones. Defaults to 0.0. [-2.0, 2.0] で 0.5 刻み
            use_merged_speaker_embedding (bool, optional): Use merged speaker embedding. Defaults to False.
        """
        block_size_in_input_sample_rate = self.block_size * self.IN_HOP_LENGTH
        sr, source_wav = wavfile.read(in_filename)
        assert sr == self.IN_SAMPLE_RATE
        assert source_wav.ndim == 1
        assert source_wav.dtype == np.int16
        source_wav = (source_wav / 32768.0).astype(np.float32)
        converted_wav_segments = []
        t0 = perf_counter()
        for left in range(0, len(source_wav), block_size_in_input_sample_rate):
            source_wav_segment = source_wav[left:left + block_size_in_input_sample_rate]
            converted_wav_segment = self.convert_segment(source_wav_segment, target_speaker_id, pitch_shift_semitones, formant_shift_semitones, use_merged_speaker_embedding)
            converted_wav_segments.append(converted_wav_segment)
        elapsed_time = perf_counter() - t0
        rtf = elapsed_time / len(source_wav) * sr
        print(f'Elapsed time: {elapsed_time:.3f}s')
        print(f'RTF: {rtf:.3f}')
        converted_wav = np.concatenate(converted_wav_segments)
        wavfile.write(out_filename, self.OUT_SAMPLE_RATE, np.round(converted_wav * 32767.0).astype(np.int16))