

import numpy as np
import torch
import torchfcpe
from voice_changer_data_types import PitchEstimatorInfo
from voice_chanager_const import PitchEstimatorType
from device_manager import DeviceManager
from pitch_estimator import PitchEstimator

class FCPEPitchEstimator(PitchEstimator):

    def __init__(self, pitch_estimator_type: PitchEstimatorType, device_id: int):
        super().__init__()
        self.device_id = device_id
        self.f0_min = 50
        self.f0_max = 1100
        self.f0_mel_min = 1127 * np.log(1 + self.f0_min / 700)
        self.f0_mel_max = 1127 * np.log(1 + self.f0_max / 700)
        self.pitch_estimator_type = pitch_estimator_type
        self.device = DeviceManager.get_instance().get_pytorch_device(device_id)
        self.fcpe = torchfcpe.spawn_bundled_infer_model(self.device)
    pass

    def estimate(self, audio: np.ndarray | torch.Tensor, prev_pitch: np.ndarray | torch.Tensor, up_key: int, sample_rate: int, window_length: int, silence_front_sec: float=0) -> tuple[torch.Tensor, torch.Tensor]:
        try:
            if isinstance(audio, np.ndarray):
                audio = torch.from_numpy(audio.astype(np.float32))
            audio = audio.float()
            audio = audio.to(self.device)
            if isinstance(prev_pitch, np.ndarray):
                prev_pitch = torch.from_numpy(prev_pitch.astype(np.float32))
            prev_pitch = prev_pitch.float()
            prev_pitch = prev_pitch.to(self.device)
            if audio.dim() != 1:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} audio.dim is not 1 (size :{audio.dim()}, {audio.shape})')
            if prev_pitch.dim() != 2:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} prevPitch.dim is not 2 (size :{prev_pitch.dim()}, {prev_pitch.shape})')
            pitch_length = audio.shape[0] // window_length
            silence_front_frame = silence_front_sec * sample_rate
            start_window = int(silence_front_frame / window_length)
            slience_front_frame_offset = start_window * window_length
            target_frame_length = len(audio) - slience_front_frame_offset
            minimum_frames = 1024
            target_frame_length = max(minimum_frames, target_frame_length)
            audio = audio.squeeze()
            audio = audio[-target_frame_length:]
            assert isinstance(audio, torch.Tensor), f'audio should be np.ndarray. {type(audio)}'
            assert isinstance(prev_pitch, torch.Tensor), f'prev_pitch should be np.ndarray. {type(prev_pitch)}'
            f0 = self.fcpe.infer(audio.unsqueeze(0), sr=16000, decoder_mode='local_argmax', threshold=0.006, f0_min=50, f0_max=1100)
            f0 = f0.squeeze()
            f0 *= pow(2, up_key / 12)
            pitch = prev_pitch.squeeze(dim=0).to(f0.device)
            pitch = torch.cat([pitch, f0], dim=0)
            if pitch.shape[0] < pitch_length:
                pitch = torch.cat([torch.zeros(pitch_length - pitch.shape[0]).to(pitch.device), pitch], dim=0)
            else:
                pitch = pitch[-pitch_length:]
            f0_mel = 1127.0 * torch.log(1.0 + pitch / 700.0)
            f0_mel[f0_mel > 0] = (f0_mel[f0_mel > 0] - self.f0_mel_min) * 254 / (self.f0_mel_max - self.f0_mel_min) + 1
            f0_mel[f0_mel <= 1] = 1
            f0_mel[f0_mel > 255] = 255
            f0_coarse = torch.round(f0_mel).int()
        except Exception as e:
            raise RuntimeError(f'Exeption in {self.__class__.__name__} audioLen:{audio.shape}', e)
        return (f0_coarse.reshape(1, -1), pitch.reshape(1, -1))

    def get_info(self) -> PitchEstimatorInfo:
        info = PitchEstimatorInfo(pitch_estimator_type='fcpe', model_file=None, device_id=self.device_id, candidate_onnx_providers=None, candidate_onnx_provider_options=None, onnx_providers=None, onnx_provider_options=None)
        return info