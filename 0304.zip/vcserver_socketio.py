import logging
import socketio
import threading
from typing import List, Optional
from const import LOG_FILE, LOGGER_NAME, SERVER_IO_RECORDING_FILE_IN, SERVER_IO_RECORDING_FILE_OUT
from vcserver import VCServer
from vcserver_rest_api import RestAPI
from server_const import VoiceChangerParams, get_frontend_path
from vcserver_socketio_server import SocketIOServer


class SocketIOApp:
    _instance = None
    @classmethod
    def get_instance(cls, app_fastapi, allow_origins):
        if cls._instance is None:
            sio = SocketIOServer.get_instance(allowed_origins=allow_origins)
            frontend_path = get_frontend_path()
            app_socketio = socketio.ASGIApp(
                sio,
                other_asgi_app=app_fastapi,
                static_files={
                    # 图标文件
                    str(frontend_path / "assets" / "icons" / "github.svg"): {
                        "filename": "/assets/icons/github.svg",
                        "content_type": "image/svg+xml"
                    },
                    str(frontend_path / "assets" / "icons" / "help-circle.svg"): {
                        "filename": "/assets/icons/help-circle.svg",
                        "content_type": "image/svg+xml"
                    },
                    str(frontend_path / "assets" / "icons" / "monitor.svg"): {
                        "filename": "/assets/icons/monitor.svg",
                        "content_type": "image/svg+xml"
                    },
                    str(frontend_path / "assets" / "icons" / "tool.svg"): {
                        "filename": "/assets/icons/tool.svg",
                        "content_type": "image/svg+xml"
                    },
                    str(frontend_path / "assets" / "icons" / "folder.svg"): {
                        "filename": "/assets/icons/folder.svg",
                        "content_type": "image/svg+xml"
                    },
                    # 图片文件
                    str(frontend_path / "assets" / "icons" / "buymeacoffee.png"): {
                        "filename": "assets/icons/buymeacoffee.png",
                        "content_type": "image/png"
                    },
                    # WASM文件
                    str(frontend_path / "ort-wasm-simd.wasm"): {
                        "filename": "/ort-wasm-simd.wasm",
                        "content_type": "application/wasm"
                    },
                    # 角色图标
                    str(frontend_path / "assets" / "beatrice_jvs" / "female-clickable.svg"): {
                        "filename": "/assets/beatrice_jvs/female-clickable.svg",
                        "content_type": "image/svg+xml"
                    },
                    str(frontend_path / "assets" / "beatrice_jvs" / "male-clickable.svg"): {
                        "filename": "/assets/beatrice_jvs/male-clickable.svg",
                        "content_type": "image/svg+xml"
                    },
                    # 前端入口
                    str(frontend_path / "index.html"): "",
                    # 日志文件
                    LOG_FILE: {
                        "filename": "/vcclient.log",
                        "content_type": "text/plain"
                    },
                    # 音频文件
                    SERVER_IO_RECORDING_FILE_IN: {
                        "filename": "/input.wav",
                        "content_type": "audio/wav"
                    },
                    SERVER_IO_RECORDING_FILE_OUT: {
                        "filename": "/output.wav",
                        "content_type": "audio/wav"
                    }
                },
            )

            cls._instance = app_socketio
        return cls._instance


# 初始化参数配置
# 获取语音转换参数
#voice_changer_params = VoiceChangerParams(model_dir='vc_model_dir')
params_dict = {"vc_model_dir": "vc_model_dir"}
voice_changer_params = VoiceChangerParams(**params_dict)
# 获取RestAPI实例
rest = RestAPI.get_instance(voice_changer_params)
# 获取VCServer实例的允许来源
allow_origins = VCServer.get_instance().allow_origins
# 记录允许来源的日志
logging.getLogger(LOGGER_NAME).info(f'SocketIOApp Allow Origins {allow_origins}')
# 获取SocketIOApp实例
serverio_app = SocketIOApp.get_instance(rest, allow_origins)