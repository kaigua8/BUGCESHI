
from pathlib import Path
import numpy as np
import torch
from torch import nn
from voice_changer_data_types import RVCInferencerInfo
from rvcv2_f0 import RVCV2F0
from device_manager import DeviceManager
from rvc_inferencer import RVCInferencer

class RVCInferencerv2F0(RVCInferencer):
    model: nn.Module

    def load_model(self, file: Path, device_id: int):
        self.file = file
        self.device_id = device_id
        self.dev = DeviceManager.get_instance().get_pytorch_device(device_id)
        self.isHalf = DeviceManager.get_instance().half_precision_available(device_id)
        cpt = torch.load(file, map_location='cpu')
        model = RVCV2F0(*cpt['config'], is_half=self.isHalf)
        model.eval()
        model.load_state_dict(cpt['weight'], strict=False)
        model = model.to(self.dev)
        if self.isHalf:
            model = model.half()
        self.model = model
        return self
    pass

    def infer(self, feats: np.ndarray | torch.Tensor, pitch_length: np.ndarray | torch.Tensor, pitch: np.ndarray | torch.Tensor | None, pitchf: np.ndarray | torch.Tensor | None, sid: np.ndarray | torch.Tensor, convert_length: int | None=None) -> torch.Tensor:
        try:
            if isinstance(feats, np.ndarray):
                feats = torch.from_numpy(feats.astype(np.float32))
            feats = feats.to(self.dev)
            if self.isHalf and feats.dtype != torch.float16:
                feats = feats.half()
            if self.isHalf is False:
                if feats.dtype != torch.float32:
                    feats = feats.float()
            if isinstance(pitch_length, np.ndarray):
                pitch_length = torch.from_numpy(pitch_length)
            pitch_length = pitch_length.to(self.dev)
            if isinstance(pitch, np.ndarray):
                pitch = torch.from_numpy(pitch)
            assert pitch is not None
            pitch = pitch.to(self.dev)
            if isinstance(pitchf, np.ndarray):
                pitchf = torch.from_numpy(pitchf.astype(np.float32))
            assert pitchf is not None
            pitchf = pitchf.to(self.dev)
            if self.isHalf and pitchf.dtype != torch.float16:
                pitchf = pitchf.half()
            if self.isHalf is False and pitchf.dtype != torch.float32:
                pitchf = pitchf.float()
            pitchf = pitchf.to(self.dev)
            if isinstance(sid, np.ndarray):
                sid = torch.from_numpy(sid)
            sid = sid.to(self.dev)
            if feats.dim() != 3:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} feats.dim is not 3 (size :{feats.dim()}, {feats.shape})')
            if pitch_length.dim() != 1:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} pitch_length.dim is not 1 (size :{pitch_length.dim()}, {pitch_length.shape})')
            if pitch.dim() != 2:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} pitch.dim is not 2 (size :{pitch.dim()}, {pitch.shape})')
            if pitchf.dim() != 2:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} pitchf.dim is not 2 (size :{pitchf.dim()}, {pitchf.shape})')
            if sid.dim() != 1:
                raise RuntimeError(f'Exeption in {self.__class__.__name__} sid.dim is not 1 (size :{sid.dim()}, {sid.shape})')
            with torch.no_grad():
                res = self.model.infer(feats, pitch_length, pitch, pitchf, sid, convert_length=convert_length)
                res = res[0]
                res = res[0, 0].to(dtype=torch.float32)
                res = torch.clip(res, -1.0, 1.0)
                return res
        except Exception as e:
            raise RuntimeError(f'Exeption in {self.__class__.__name__}', e)

    def get_info(self) -> RVCInferencerInfo:
        info = RVCInferencerInfo(inferencer_type='pyTorchRVCv2', model_file=self.file, device_id=self.device_id, candidate_onnx_providers=None, candidate_onnx_provider_options=None, onnx_providers=None, onnx_provider_options=None)
        return info