

import logging
from pathlib import Path
from typing import Any, Dict, OrderedDict
import torch
from const import LOGGER_NAME
from exception import ERROR_CODE_RVC_MERGE_FAILED_ALL_MODELS_NOT_SAME, ERROR_CODE_RVC_MERGE_FAILED_FIRST_MODEL_NOT_FOUND, ERROR_CODE_RVC_MERGE_FAILED_INVALID_PARAM, ERROR_CODE_RVC_MERGE_FAILED_MODEL_NOT_FOUND, ERROR_CODE_RVC_MERGE_FAILED_UNSUPPORTED_MODEL_TYPE, ERROR_CODE_RVC_MERGE_FAILED_WEIGHT_KEY_IS_NOT_MATCH, VCClientError
from slot_manager_data_types import MergeParam
from slot_manager_data_types import RVCSlotInfo
from slot_manager import SlotManager
from voice_chanager_const import ModelDir

class RVCModelMerger:

    def _estimate_inferencer_type(self, params: MergeParam):
        first_model = SlotManager.get_instance().get_slot_info(params.files[0].slot_index)
        if first_model is None:
            raise VCClientError(ERROR_CODE_RVC_MERGE_FAILED_FIRST_MODEL_NOT_FOUND)
        assert isinstance(first_model, RVCSlotInfo), f'first_model is not RVCSlotInfo: {first_model}0'
        for f in params.files:
            rvc_slot_info = SlotManager.get_instance().get_slot_info(f.slot_index)
            if rvc_slot_info is None:
                raise VCClientError(ERROR_CODE_RVC_MERGE_FAILED_MODEL_NOT_FOUND)
            assert isinstance(rvc_slot_info, RVCSlotInfo), f'model is not RVCSlotInfo: {rvc_slot_info}0'
            if rvc_slot_info.inferencer_type != first_model.inferencer_type:
                raise VCClientError(ERROR_CODE_RVC_MERGE_FAILED_ALL_MODELS_NOT_SAME, f'model.inferencer_type != first_model.inferencer_type: {rvc_slot_info.inferencer_type} != {first_model.inferencer_type}0')
        else:
            return first_model.inferencer_type

    def _extract(self, ckpt: Dict[str, Any]):
        a = ckpt['model']
        opt = OrderedDict()
        opt['weight'] = {}
        for key in a.keys():
            if 'enc_q' in key:
                continue
            opt['weight'][key] = a[key]
        return opt

    def _load_weight(self, model_file: Path):
        state_dict = torch.load(model_file, map_location='cpu')
        logging.getLogger(LOGGER_NAME).info(f'statedict:{state_dict.keys()}')
        if 'model' in state_dict:
            logging.getLogger(LOGGER_NAME).warn('pth has model attribute.')
            weight = self._extract(state_dict)
            return (weight, state_dict)
        weight = state_dict['weight']
        return (weight, state_dict)

    def merge(self, store_path: Path, params: MergeParam):
        if len(params.files) == 0:
            raise VCClientError(ERROR_CODE_RVC_MERGE_FAILED_INVALID_PARAM, 'len(params.files) == 0')
        inferencer_type = self._estimate_inferencer_type(params)
        if inferencer_type not in ['pyTorchRVC', 'pyTorchRVCNono', 'pyTorchRVCv2', 'pyTorchRVCv2Nono', 'pyTorchDDPN', 'pyTorchDDPNNono']:
            logging.getLogger(LOGGER_NAME).error(f'rvc merge, unsupported inferencer_type:{inferencer_type}0')
            raise VCClientError(ERROR_CODE_RVC_MERGE_FAILED_UNSUPPORTED_MODEL_TYPE, f'unsupported inferencer_type:{inferencer_type}0')
        weights = []
        alphas = []
        for f in params.files:
            if f.strength == 0:
                continue
            rvc_slot_info = SlotManager.get_instance().get_slot_info(f.slot_index)
            assert isinstance(rvc_slot_info, RVCSlotInfo), f'model is not RVCSlotInfo: {rvc_slot_info}0'
            assert rvc_slot_info.model_file is not None, f'model_file is None: {rvc_slot_info}0'
            weight, state_dict = self._load_weight(Path(ModelDir / str(rvc_slot_info.slot_index) / rvc_slot_info.model_file))
            weights.append(weight)
            alphas.append(f.strength)
        else:
            alphas = [x / sum(alphas) for x in alphas]
            for weight in weights:
                if sorted(list(weight.keys())) != sorted(list(weights[0].keys())):
                    logging.getLogger(LOGGER_NAME).error('weight key is not match between models.')
                    logging.getLogger(LOGGER_NAME).error(f'{sorted(list(weight.keys()))}')
                    logging.getLogger(LOGGER_NAME).error(f'{sorted(list(weights[0].keys()))}')
                    raise VCClientError(ERROR_CODE_RVC_MERGE_FAILED_WEIGHT_KEY_IS_NOT_MATCH)
            else:
                merged = OrderedDict()
                merged['weight'] = {}
                logging.getLogger(LOGGER_NAME).info('merge rvc model start')
                for key in weights[0].keys():
                    merged['weight'][key] = 0
                    for i, weight in enumerate(weights):
                        merged['weight'][key] += weight[key] * alphas[i]
                logging.getLogger(LOGGER_NAME).info('merge done. generating metadata.')
                merged['config'] = state_dict['config']
                merged['params'] = state_dict['params'] if 'params' in state_dict else None
                merged['version'] = state_dict['version'] if 'version' in state_dict else None
                merged['sr'] = state_dict['sr']
                merged['f0'] = state_dict['f0']
                merged['info'] = state_dict['info']
                merged['embedder_name'] = state_dict['embedder_name'] if 'embedder_name' in state_dict else None
                merged['embedder_output_layer'] = state_dict['embedder_output_layer'] if 'embedder_output_layer' in state_dict else None
                logging.getLogger(LOGGER_NAME).info('metadata is generated.')
                torch.save(merged, store_path)