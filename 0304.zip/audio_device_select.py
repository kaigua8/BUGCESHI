

from pydantic import BaseModel
from textual import on
from textual.widgets import Button, Select, Label
from textual.screen import Screen
from textual.app import ComposeResult
from textual.widgets import RadioButton, RadioSet
from textual.containers import ScrollableContainer, Container
from textual.containers import Horizontal
from textual.keys import Keys
from audio_device_manager import AudioDeviceManager
from configuration_manager import ConfigurationManager
from voice_chanager_const import AudioDevicePurpose, AudioSampleRates

class SelectedAudioDevice(BaseModel):
    device_id: int
    sample_rate: int

class AudioDeviceSelect(Screen):
    DEFAULT_CSS = '\n        AudioDeviceSelect{\n            layout: grid;\n            grid-size: 2 8;\n            .select_audio_device_title {\n                background: blue;\n                column-span: 2;\n                width: 1fr;\n            }\n            .audio_device_list{\n                border: solid $success;\n                border_title_align: left;\n                overflow_x: hidden;\n                column-span: 2;\n                row-span: 5;\n                width: 1fr;\n            }\n            .sample-rate-area{\n                padding: 0 10 0 10;\n                border: none;\n                overflow_x: hidden;\n                column-span: 2;\n                width: 1fr;\n            }\n            .button-area{\n                align: center bottom;\n            }\n        }\n\n    '
    BINDINGS = [(Keys.Escape, 'cancelation', 'cancel')]

    def __init__(self, purpose: AudioDevicePurpose, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.purpose = purpose

    def _get_current_configuration(self):
        configuration_manager = ConfigurationManager.get_instance()
        configuration = configuration_manager.get_voice_changer_configuration()
        audio_device_manager = AudioDeviceManager.get_instance()
        if self.purpose == 'audioinput':
            devices = audio_device_manager.get_audio_input_devices()
            current_device_index = configuration.audio_input_device_index
            current_sample_rate = configuration.audio_input_device_sample_rate
        elif self.purpose == 'audiooutput':
            devices = audio_device_manager.get_audio_output_devices()
            current_device_index = configuration.audio_output_device_index
            current_sample_rate = configuration.audio_output_device_sample_rate
        else:
            devices = audio_device_manager.get_audio_output_devices()
            current_device_index = configuration.audio_monitor_device_index
            current_sample_rate = configuration.audio_monitor_device_sample_rate
        return (devices, current_device_index, current_sample_rate)

    def _reload_current_to_temporal_configuration(self):
        devices, current_device_index, current_sample_rate = self._get_current_configuration()
        self.devices = devices
        self.tmp_device_index = current_device_index
        self.tmp_sample_rate = current_sample_rate

    def compose(self) -> ComposeResult:
        self._reload_current_to_temporal_configuration()
        self.screen_title = Label(f'Select Audio Device ({self.purpose})', classes='select_audio_device_title')
        yield self.screen_title
        with ScrollableContainer(classes='audio_device_list') as c:
            c.border_title = 'Audio Devices'
            with RadioSet():
                text = '-1. not selected'
                yield RadioButton(text, id=f'select_{self.purpose}_index_-1', value=True if self.tmp_device_index == -1 else False)
                for device in self.devices:
                    text = f'{device.index:02d}. [{device.host_api}] {device.name}'
                    yield RadioButton(text, id=f'select_{self.purpose}_index_{device.index}', value=True if self.tmp_device_index == device.index else False)
        with Horizontal(classes='sample-rate-area'):
            yield Label('Sample Rate:')
            options = [(f'{sr}', sr) for sr in AudioSampleRates]
            options.insert(0, ('auto', -1))
            s = Select(options, allow_blank=False, value=self.tmp_sample_rate, id=f'select_{self.purpose}_sample_rate')
            yield s
        with Container(classes='button-area'):
            yield Button('OK', id='select_device_ok')
        with Container(classes='button-area'):
            yield Button('Cancel', id='select_device_cancel')

    def on_radio_set_changed(self, radio_set: RadioSet) -> None:
        self.tmp_device_index = int(radio_set.pressed.id.split('_')[-1])

    def on_select_changed(self, select: Select) -> None:
        try:
            self.tmp_sample_rate = int(select.value)
        except:
            return None

    @on(Button.Pressed, '#select_device_cancel')
    def on_cancel_button_pressed(self, event: Button.Pressed) -> None:
        self.cancelation()

    @on(Button.Pressed, '#select_device_ok')
    def on_ok_button_pressed(self, event: Button.Pressed) -> None:
        audio_device_manager = AudioDeviceManager.get_instance()
        _devices, current_device_index, current_sample_rate = self._get_current_configuration()
        if self.tmp_device_index == -1:
            self.dismiss(SelectedAudioDevice(device_id=self.tmp_device_index, sample_rate=self.tmp_sample_rate))
            return
        if self.tmp_sample_rate == -1:
            self.dismiss(SelectedAudioDevice(device_id=self.tmp_device_index, sample_rate=self.tmp_sample_rate))
            return
        available = audio_device_manager.check_available_sample_rate(self.tmp_device_index, self.tmp_sample_rate, self.purpose)
        if available is True:
            self.dismiss(SelectedAudioDevice(device_id=self.tmp_device_index, sample_rate=self.tmp_sample_rate))
            return
        self.notify(f'Index: {current_device_index} -> {self.tmp_device_index}\nSampleRate: {current_sample_rate} -> {self.tmp_sample_rate}', title=f'Audio Device Changed ({self.purpose}) Failed', timeout=3.0, severity='error')
        self.initialize()
        self.compose()

    def initialize(self):
        self._reload_current_to_temporal_configuration()
        id = f'select_{self.purpose}_index_{self.tmp_device_index}'
        audio_device_radio_button = self.query_one(f'#{id}', RadioButton)
        audio_device_radio_button.value = True
        id = f'select_{self.purpose}_sample_rate'
        audio_device_sample_rate = self.query_one(f'#{id}', Select)
        audio_device_sample_rate.value = self.tmp_sample_rate

    def cancelation(self):
        self._reload_current_to_temporal_configuration()
        self.dismiss(None)

    def action_cancelation(self):
        self.cancelation()