

from pathlib import Path
import torch
from torch import nn
from voice_changer_data_types import RVCInferencerInfo
from models import RVCDDPNNoF0
from device_manager import DeviceManager
from rvc_inverencer_v2_nof0 import RVCInferencerv2NoF0

class RVCInferencerDDPNNoF0(RVCInferencerv2NoF0):
    model: nn.Module

    def load_model(self, file: Path, device_id: int):
        self.file = file
        self.device_id = device_id
        self.dev = DeviceManager.get_instance().get_pytorch_device(device_id)
        self.isHalf = DeviceManager.get_instance().half_precision_available(device_id)
        cpt = torch.load(file, map_location='cpu')
        model = RVCDDPNNoF0(*cpt['config'], is_half=self.isHalf)
        model.eval()
        model.load_state_dict(cpt['weight'], strict=False)
        model = model.to(self.dev)
        if self.isHalf:
            model = model.half()
        self.model = model
        return self

    def get_info(self) -> RVCInferencerInfo:
        info = RVCInferencerInfo(inferencer_type='pyTorchDDPNNono', model_file=self.file, device_id=self.device_id, candidate_onnx_providers=None, candidate_onnx_provider_options=None, onnx_providers=None, onnx_provider_options=None)
        return info