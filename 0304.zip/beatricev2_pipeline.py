
import logging
from typing import Any
import numpy as np
from const import LOGGER_NAME
from voice_changer_data_types import PipelineInfo, PipelineInfoMember
from voice_chanager_const import GET_GPU_DEVICE_ID_IS_NOT_AVAILABLE, MAX_BEATRICE_MERGED_SPEAKER_WEIGHTS_SLOT, PitchEstimatorType
from slot_manager_data_types import BeatriceV2SlotInfo, SlotInfoMember
from slot_manager import SlotManager
from vc_pipeline import VCPipeline
from simple_beatrice import SimpleBeatrice

class BeatriceV2Pipeline(VCPipeline):

    def __init__(self, slot_info: SlotInfoMember):
        assert isinstance(slot_info, BeatriceV2SlotInfo)
        self.slot_info = slot_info
        self.slot_index = self.slot_info.slot_index
        self.model_version = self.slot_info.model_info.model.version
        try:
            self.beatrice = SimpleBeatrice(model_version=self.model_version, phone_extractor_parameter_file=self.slot_info.phone_extractor_file, pitch_estimator_parameter_file=self.slot_info.pitch_estimator_file, formant_shift_embeddings_file=self.slot_info.formant_shift_embeddings_file, speaker_embeddings_file=self.slot_info.speaker_embeddings_file, waveform_generator_parameter_file=self.slot_info.waveform_generator_file)
        except Exception as e:
            logging.getLogger(LOGGER_NAME).error(f'failed to initialize BeatriceV2Pipeline: {e}')
        self.use_merged_speaker_embedding = False
        self.merged_speaker_id = 0
        self.target_merged_speaker_weights = [1.0] * self.beatrice.get_target_speaker_num()
        self.auto_picth_shift_enabled = False
        self.source_average_pitch = -1.0
        self.source_pitch = []

    def get_input_sample_rate(self) -> int:
        return self.beatrice.IN_SAMPLE_RATE

    def get_output_sample_rate(self) -> int:
        return self.beatrice.OUT_SAMPLE_RATE

    def get_input_bitdepth(self):
        return np.float32

    def get_output_bitdepth(self):
        return np.float32

    def get_chunk_sec(self) -> float:
        return self.beatrice.IN_HOP_LENGTH / self.beatrice.IN_SAMPLE_RATE

    def needs_crossfade(self) -> bool:
        return False

    def get_pitch_estimator_type(self) -> None:
        return

    def get_gpu_device_id(self) -> int:
        return GET_GPU_DEVICE_ID_IS_NOT_AVAILABLE

    def set_pitch_estimator_type(self, pitch_estimator_type: PitchEstimatorType):
        return

    def check_and_update_merged_speaker_setting(self):
        slot_info = SlotManager.get_instance().get_slot_info(self.slot_index)
        assert isinstance(slot_info, BeatriceV2SlotInfo)
        assert slot_info.merged_speaker_id < len(slot_info.merged_speaker_weights_list)
        need_update = False
        if slot_info.use_merged_speaker_embedding != self.use_merged_speaker_embedding:
            self.use_merged_speaker_embedding = slot_info.use_merged_speaker_embedding
            need_update = True
        if slot_info.merged_speaker_id != self.merged_speaker_id:
            self.merged_speaker_id = slot_info.merged_speaker_id
            need_update = True
        target_merged_speaker_weights = slot_info.merged_speaker_weights_list[slot_info.merged_speaker_id]
        assert len(target_merged_speaker_weights) == self.beatrice.get_target_speaker_num()
        for i in range(len(target_merged_speaker_weights)):
            if target_merged_speaker_weights[i] != self.target_merged_speaker_weights[i]:
                self.target_merged_speaker_weights = target_merged_speaker_weights
                self.max_value_index = self.target_merged_speaker_weights.index(max(self.target_merged_speaker_weights))
                average_pitchs = [val.average_pitch for key, val in slot_info.model_info.voice.items()]
                self.weighted_average_pitch = sum([average_pitchs[i] * self.target_merged_speaker_weights[i] for i in range(len(average_pitchs))]) / sum(self.target_merged_speaker_weights)
                need_update = True
                break
        if need_update and self.use_merged_speaker_embedding:
            self._apply_merged_speaker_weights()
        if slot_info.auto_pitch_shift != self.auto_picth_shift_enabled:
            self.auto_picth_shift_enabled = slot_info.auto_pitch_shift
            self.source_average_pitch = -1.0

    def _apply_merged_speaker_weights(self):
        assert len(self.target_merged_speaker_weights) == self.beatrice.get_target_speaker_num()
        try:
            self.beatrice.set_target_speaker_weights(np.array(self.target_merged_speaker_weights, dtype=np.float32))
        except Exception as e:
            logging.getLogger(LOGGER_NAME).error(f'failed to set_target_speaker_weights: {e}')
            print(f'failed to set_target_speaker_weights: {e}')

    def run(self, audio: np.ndarray[Any, np.dtype[float | np.float32]], real_crossfade_sec: float=0) -> np.ndarray[Any, np.dtype[float]]:
        self.check_and_update_merged_speaker_setting()
        slot_info = SlotManager.get_instance().get_slot_info(self.slot_index)
        if audio.dtype != np.float32:
            audio = audio.astype(np.float32)
        if self.use_merged_speaker_embedding:
            pitch_shift = slot_info.merged_speaker_pitch_shifts[slot_info.merged_speaker_id] if slot_info.merged_speaker_id < len(slot_info.merged_speaker_pitch_shifts) else 0
            formant_shift = slot_info.merged_speaker_formant_shifts[slot_info.merged_speaker_id] if slot_info.merged_speaker_id < len(slot_info.merged_speaker_formant_shifts) else 0.0
        else:
            pitch_shift = slot_info.pitch_shifts[slot_info.dst_id] if slot_info.dst_id < len(slot_info.pitch_shifts) else 0
            formant_shift = slot_info.formant_shifts[slot_info.dst_id] if slot_info.dst_id < len(slot_info.formant_shifts) else 0.0
        if formant_shift not in [2.0, 1.5, 1.0, 0.5, 0, -0.5, -1.0, -1.5, -2.0]:
            formant_shift = 0.0
        auto_pitch_shift_calibration_times = 10
        need_calculate_source_average_pitch = False
        if slot_info.auto_pitch_shift == True:
            if self.use_merged_speaker_embedding:
                target_average_pitch = self.weighted_average_pitch
            else:
                target_average_pitch = slot_info.model_info.voice[f'{slot_info.dst_id}'].average_pitch
            if self.source_average_pitch < 0:
                need_calculate_source_average_pitch = True
                if len(self.source_pitch) < auto_pitch_shift_calibration_times and len(self.source_pitch) > 0:
                    tmp_pitch = sum(self.source_pitch) / len(self.source_pitch)
                    pitch_shift = target_average_pitch - tmp_pitch
            else:
                pitch_shift = target_average_pitch - self.source_average_pitch
        converted, source_average_pitch = self.beatrice.convert_segment(audio[:self.beatrice.IN_HOP_LENGTH], slot_info.dst_id, pitch_shift, formant_shift, use_merged_speaker_embedding=self.use_merged_speaker_embedding, calculate_source_average_pitch=need_calculate_source_average_pitch)
        if need_calculate_source_average_pitch == True:
            if len(self.source_pitch) < auto_pitch_shift_calibration_times:
                if source_average_pitch > 35 and source_average_pitch < 80:
                    self.source_pitch.append(source_average_pitch)
                return converted
            average_pitch = sum(self.source_pitch) / len(self.source_pitch)
            self.source_average_pitch = average_pitch
            self.source_pitch = []
        return converted

    def get_pipeline_info(self) -> PipelineInfoMember:
        return PipelineInfo(slot_index=self.slot_index, input_sample_rate=self.get_input_sample_rate(), output_sample_rate=self.get_output_sample_rate(), chunk_sec=self.get_chunk_sec(), slot_info=self.slot_info.model_dump())