#!/usr/bin/env python
# visit https://tool.lu/pyc/ for more information

import logging
import socketio
from const import LOG_FILE, LOGGER_NAME, SERVER_IO_RECORDING_FILE_IN, SERVER_IO_RECORDING_FILE_OUT
from vcserver import VCServer
from vcserver_rest_api import RestAPI
from server_const import VoiceChangerParams, get_frontend_path
from vcserver_socketio_server import SocketIOServer
print("aaaa== START INITIALIZATION =====")  # 确认整个代码块是否运行
class SocketIOApp:
    _instance = None
    print("===== START INITIALIZATION =====")  # 确认整个代码块是否运行
    @classmethod
    def get_instance(cls, app_fastapi, allow_origins: list[str] = None):
        if cls._instance is None:

            print(f"[Debug] Frontend path: {get_frontend_path()}")  # 打印前端路径
            sio = SocketIOServer.get_instance(allow_origins=allow_origins)
            app_socketio = socketio.ASGIApp(
                sio,
                app_fastapi,
                static_files={
                    f"{get_frontend_path()}/assets/icons/github.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/assets/icons/help-circle.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/assets/icons/monitor.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/assets/icons/tool.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/assets/icons/folder.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/assets/icons/buymeacoffee.png": {
                        "filename": "image/png",
                        "content_type": "image/png"
                    },
                    f"{get_frontend_path()}/ort-wasm-simd.wasm": {
                        "filename": "application/wasm",
                        "content_type": "application/wasm"
                    },
                    f"{get_frontend_path()}/assets/beatrice_jvs/female-clickable.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/assets/beatrice_jvs/male-clickable.svg": {
                        "filename": "image/svg+xml",
                        "content_type": "image/svg+xml"
                    },
                    f"{get_frontend_path()}/index.html": {},
                    f"{LOG_FILE}": {
                        "filename": "text/plain",
                        "content_type": "text/plain"
                    },
                    f"{SERVER_IO_RECORDING_FILE_IN}": {
                        "filename": "audio/wav",
                        "content_type": "audio/wav"
                    },
                    f"{SERVER_IO_RECORDING_FILE_OUT}": {
                        "filename": "audio/wav",
                        "content_type": "audio/wav"
                    },
                    "/assets/icons/github.svg": {},
                    "/assets/icons/help-circle.svg": {},
                    "/assets/icons/monitor.svg": {},
                    "/assets/icons/tool.svg": {},
                    "/assets/icons/folder.svg": {},
                    "assets/icons/buymeacoffee.png": {},
                    "/ort-wasm-simd.wasm": {},
                    "/assets/beatrice_jvs/female-clickable.svg": {},
                    "/assets/beatrice_jvs/male-clickable.svg": {},
                    "": {},
                    "/": {},
                    "/vcclient.log": {},
                    "/input.wav": {},
                    "/output.wav": {}
                }
            )

            cls._instance = app_socketio

        return cls._instance
print("===== START INITIALIZATION =====")  # 确认整个代码块是否运行
voice_changer_params = VoiceChangerParams(model_dir=('vc_model_dir',))
rest = RestAPI.get_instance(voice_changer_params)
allow_origins = VCServer.get_instance().allow_origins
logging.getLogger(LOGGER_NAME).info('SocketIOApp Allow Origins ' + f'{allow_origins}')
print("Before calling SocketIOApp.get_instance()")
serverio_app = SocketIOApp.get_instance(rest, allow_origins=allow_origins)
print("After calling SocketIOApp.get_instance()")
