
from importlib import import_module
from types import ModuleType
from typing import Literal
#from .spherical_average import SphericalAverage
ParaphernaliaVersion = Literal['2.0.0-alpha.2', '2.0.0-beta.1']
_VERSION_MAP: dict[ParaphernaliaVersion, str] = {'2.0.0-alpha.2': 'v20a2', '2.0.0-beta.1': 'v20b1'}

def load_beatrice(version: ParaphernaliaVersion) -> ModuleType:
    if version not in _VERSION_MAP:
        raise ValueError(f'Unsupported paraphernalia version: {version}')
    module_name = _VERSION_MAP[version]
    return import_module(f'.{module_name}', __package__)