from data_types import RVCSampleInfo, SampleInfoMember

# 定义多个 RVC 示例信息
sample1 = RVCSampleInfo(
    id='KikotoKurage_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'onnx'],
    name='黄琴海月(onnx)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_kurage/kikoto_kurage_v2_40k_e100_float.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_kurage/added_IVF5181_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/kikoto_kurage/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_kurage/kikoto_kurage.png',
    credit='黄琴海月',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample2 = RVCSampleInfo(
    id='KikotoMahiro_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'onnx'],
    name='黄琴まひろ(onnx)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_mahiro/kikoto_mahiro_v2_40k_float.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_mahiro/added_IVF6881_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/kikoto_mahiro/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/kikoto_mahiro/kikoto_mahiro.png',
    credit='黄琴まひろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample3 = RVCSampleInfo(
    id='TokinaShigure_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'onnx'],
    name='刻鳴時雨(onnx)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tokina_shigure/tokina_shigure_v2_40k_e100_float.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tokina_shigure/added_IVF2736_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/tokina_shigure/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tokina_shigure/tokina_shigure.png',
    credit='刻鳴時雨',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample4 = RVCSampleInfo(
    id='Amitaro_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'onnx'],
    name='あみたろ(onnx)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/amitaro/amitaro_v2_40k_e100_float.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/amitaro/added_IVF3139_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/amitaro/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/amitaro/amitaro.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample5 = RVCSampleInfo(
    id='Tsukuyomi-chan_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['v2', 'onnx'],
    name='つくよみちゃん(onnx)',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tsukuyomi-chan/tsukuyomi_v2_40k_e100_float.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tsukuyomi-chan/added_IVF7852_Flat_nprobe_1_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/rvc_v2_alpha/tsukuyomi-chan/terms_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/rvc_v2_alpha/tsukuyomi-chan/tsukuyomi-chan.png',
    credit='つくよみちゃん',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

# 将所有示例信息存储在列表中
SAMPLE_RVC_ONNX = [sample1, sample2, sample3, sample4, sample5]

# 设置类型注解
# __annotations__['SAMPLE_RVC_ONNX'] = list[SampleInfoMember]