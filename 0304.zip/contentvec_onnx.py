

import logging
from pathlib import Path
import numpy as np
import torch
import onnxruntime
from const import LOGGER_NAME
from voice_changer_data_types import EmbedderInfo
from device_manager import DeviceManager
from embedder import Embedder

class ContentvecOnnx(Embedder):

    def load_model(self, model_file: Path, device_id: int, layer: int, use_final_proj: bool) -> Embedder:
        self.model_file = model_file
        self.deviceId = device_id
        self.layer = layer
        self.useFinalProj = use_final_proj
        onnx_providers, onnx_provider_options = DeviceManager.get_instance().get_onnx_execution_provider(self.deviceId)
        self.candidate_onnx_providers = onnx_providers
        self.candidate_onnx_provider_options = onnx_provider_options
        so = onnxruntime.SessionOptions()
        so.log_severity_level = 3
        self.onnx_session = onnxruntime.InferenceSession(str(model_file), sess_options=so, providers=onnx_providers, provider_options=onnx_provider_options)
        first_input_type = self.onnx_session.get_inputs()[0].type
        if first_input_type == 'tensor(float)':
            self.isHalf = False
            return self
        self.isHalf = True
        return self

    def extract_features(self, audio: np.ndarray | torch.Tensor) -> np.ndarray:
        """b'\\n        \\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x83\\x87\\xe3\\x83\\xbc\\xe3\\x82\\xbf\\xe3\\x81\\x8b\\xe3\\x82\\x8920ms\\xe3\\x81\\x94\\xe3\\x81\\xa8\\xe3\\x81\\xae\\xe7\\x89\\xb9\\xe5\\xbe\\xb4\\xe3\\x82\\x92\\xe6\\x8a\\xbd\\xe5\\x87\\xba\\xe3\\x81\\x99\\xe3\\x82\\x8b\\n        Args:\\n            audio: np.array(np.float32 or np.float64) or torch.Tensor(torch.float32 or torch.float16) [n]\\n\\n        Returns:\\n            feats: torch.Tensor or np.array [1, n, 768] or [1, n, 256]\\n        '"""
        try:
            if isinstance(audio, torch.Tensor) is True:
                assert isinstance(audio, torch.Tensor)
                audio = audio.cpu().numpy()
            assert isinstance(audio, np.ndarray)
            if audio.ndim != 1:
                logging.getLogger(LOGGER_NAME).error(f'Exeption in {self.__class__.__name__} audio.dim is not 1 (size :{audio.ndim}, {audio.shape})')
                raise RuntimeError(f'Exeption in {self.__class__.__name__} audio.ndim is not 1 (size :{audio.ndim}, {audio.shape})')
            audio = audio.reshape(1, -1)
            if self.isHalf:
                unit = self.onnx_session.run(['units9', 'unit12', 'unit12s'], {'audio': audio.astype(np.float16)})
            else:
                unit = self.onnx_session.run(['units9', 'unit12', 'unit12s'], {'audio': audio.astype(np.float32)})
            if self.layer == 9:
                res = unit[0]
                return res
            res = unit[1]
            return res
        except Exception as e:
            raise RuntimeError(f'Exeption in {self.__class__.__name__}', e)

    def get_info(self) -> EmbedderInfo:
        info = EmbedderInfo(embedder_type='contentvec', model_file=self.model_file, device_id=self.deviceId, candidate_onnx_providers=self.candidate_onnx_providers, candidate_onnx_provider_options=str(self.candidate_onnx_provider_options), onnx_providers=self.onnx_session.get_providers(), onnx_provider_options=str(self.onnx_session.get_provider_options()))
        return info