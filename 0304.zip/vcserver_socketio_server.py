import socketio
from textual import logging

from vcserver_socketio_namespace import SocketIONamespace


# class SocketIOServer:
#     _instance = None
#
#     @classmethod
#     def get_instance(cls, allowed_origins=None):
#         if cls._instance is None:
#             if allowed_origins is None:
#                 sio = socketio.AsyncServer(async_mode='asgi')
#             else:
#                 sio = socketio.AsyncServer(async_mode='asgi', cors_allowed_origins=allowed_origins)
#             cls._instance = sio
#
#             namespace = SocketIONamespace.get_instance(cls._instance.list_all_sids)
#             cls._instance.register_namespace(namespace)
#
#         return cls._instance
#
#     def list_all_sids(self, namespace, room):
#         participants = self.manager.get_participants(namespace, room=room)
#         return [sid for sid in participants]
class SocketIOServer(socketio.AsyncServer):
    _instance = None

    def __init__(self, allowed_origins=None):
        super().__init__(async_mode='asgi', cors_allowed_origins=allowed_origins)

    @classmethod
    def get_instance(cls, allowed_origins=None):
        if cls._instance is None:
            cls._instance = cls(allowed_origins)

            namespace = SocketIONamespace.get_instance(cls._instance.list_all_sids)
            cls._instance.register_namespace(namespace)

        return cls._instance

    def list_all_sids(self, namespace, room):
        participants = self.manager.get_participants(namespace, room=room)
        return [sid for sid in participants]