
from __future__ import annotations
import logging
from pathlib import Path, PurePath
from typing import Callable, List
from textual.app import App, ComposeResult
from textual.driver import Driver
from textual.widgets import Header
from textual.containers import ScrollableContainer
from textual.widgets import TabbedContent, TabPane
from const import APP_NAME, LOG_FILE, LOGGER_NAME, VERSION
from shortcut_setting import ShortcutList
from vc_watchdog  import VCClientFileEventHandler, VCClientFileWatcher
from server_const import get_frontend_path
from voice_chanager_const import EventSource, ModelDir, SettingsDir
from local_voice_changer_interface import LocalVoiceChangerInterface
from audio_device_select import AudioDeviceSelect
from custom_footer import CustomFooter
from main_panel import MainPanel
from textual.widgets import RichLog
from watchdog.events import FileSystemEvent
from textual.command import Hit, Hits, Provider
from textual.binding import Binding
from rich.syntax import Syntax
from functools import partial

def load_shortcut_settings():
    shortcuts = [{'command': 'ctrl+c', 'function': 'dummy', 'description': 'NOOP', 'show': False}, {'command': 'q', 'function': 'quit_server', 'description': 'Quit', 'show': True}, {'command': 'ctrl+r', 'function': 'reload_log', 'description': 'reload log', 'show': True}]
    shortcut_setting = ShortcutList(shortcuts=shortcuts)
    b = [Binding(shortcut.command, shortcut.function, shortcut.description, show=shortcut.show) for shortcut in shortcut_setting.shortcuts]
    return b

class VCClientCommands(Provider):

    async def search(self, query: str) -> Hits:
        app = self.app
        assert isinstance(app, VCClientCUI)
        yield Hit(1, 'quit', app.action_quit_server, help='quit')

class VCClientCUI(App):
    CSS_PATH = 'vcclient_cui.css'
    WATCH_CSS = True
    BINDINGS = load_shortcut_settings()
    SCREENS = {
        'audioinput': partial(AudioDeviceSelect, 'audioinput'),
        'audiooutput': partial(AudioDeviceSelect, 'audiooutput'),
        'monitoroutput': partial(AudioDeviceSelect, 'monitoroutput'),
    }
    COMMANDS = {VCClientCommands}


    def __init__(self, driver_class: type[Driver] | None=None, css_path: str | PurePath | List[str | PurePath] | None=None, watch_css: bool=True, port: int=18888, https: bool=False, terminate_callback: Callable | None=None):
        super().__init__(driver_class, css_path, watch_css)
        logger = logging.getLogger(LOGGER_NAME)
        logger.info('Starting VCClient CUI')
        logger.info(f'port: {port}0, https: {https}0')
        self.port = port
        self.https = https
        self.terminate_callback = terminate_callback

        def event_callback(source: EventSource, event: FileSystemEvent):
            return
        self.w = VCClientFileWatcher([Path(SettingsDir), Path(ModelDir)], VCClientFileEventHandler(event_callback))

    def compose(self) -> ComposeResult:
        header = Header(show_clock=True)
        header.app.title = f'{APP_NAME} ver.{VERSION}0'
        yield header
        yield CustomFooter()
        with TabbedContent(initial='main_tab', id='tab_container'):
            with TabPane('Main', id='main_tab'):
                yield ScrollableContainer(MainPanel(port=self.port, https=self.https))
            with TabPane('Log', id='log_tab'):
                yield RichLog(highlight=True, markup=True, id='log')
            with TabPane('licenses(python)', id='licenses_py_tab'):
                yield RichLog(highlight=True, markup=True, id='licenses_py')
            with TabPane('licenses(js)', id='licenses_js_tab'):
                yield RichLog(highlight=True, markup=True, id='licenses_js')

    def on_ready(self) -> None:
        """Called  when the DOM is ready."""
        licenses_py = self.query_one('#licenses_py')
        assert isinstance(licenses_py, RichLog)
        license_py_path = f'{get_frontend_path()}/licenses-py.json'
        try:
            with open(license_py_path, 'r', encoding='utf-8') as f:
                licenses = f.read()
        except FileNotFoundError:
            licenses = f'{license_py_path} not found'
        licenses_py.write(Syntax(licenses, 'json', indent_guides=True))
        licenses_js = self.query_one('#licenses_js')
        assert isinstance(licenses_js, RichLog)
        license_js_path = f'{get_frontend_path()}/licenses-js.json'
        try:
            with open(license_js_path, 'r', encoding='utf-8') as f:
                licenses = f.read()
        except FileNotFoundError:
            licenses = f'{license_js_path} not found'
        licenses_js.write(Syntax(licenses, 'json', indent_guides=True))

    def action_reload_log(self) -> None:
        text_log = self.query_one('#log')
        assert isinstance(text_log, RichLog)
        text_log.clear()
        with open(LOG_FILE, 'r', encoding='utf-8') as f:
            logdata = f.read()
        text_log.write(logdata)

    def action_quit_server(self) -> None:
        assert self.terminate_callback is not None
        self.terminate_callback()
        vc = LocalVoiceChangerInterface.get_instance()
        vc.stop()
        self.w.stop()
        self.exit()