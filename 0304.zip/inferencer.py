
from abc import ABC, abstractmethod
from typing import Any

class Inferencer(ABC):

    @abstractmethod
    def get_info(self) -> Any:
        return