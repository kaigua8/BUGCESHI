

from pathlib import Path
from rvc_inverencer_onnx_f0 import RVCInferencerOnnxF0
from rvc_inverencer_onnx_nof0 import RVCInferencerOnnxNoF0
from inferencer import Inferencer
from rvc_inverencer_ddpn_f0 import RVCInferencerDDPNF0
from rvc_inverencer_ddpn_nof0 import RVCInferencerDDPNNoF0
from rvc_inverencer_v1_f0 import RVCInferencerv1F0
from rvc_inverencer_v1_nof0 import RVCInferencerv1NoF0
from rvc_inverencer_v2_f0 import RVCInferencerv2F0
from rvc_inverencer_v2_nof0 import RVCInferencerv2NoF0
from voice_chanager_const import InferencerType, RVCInferencerOnnxVersion

class InferencerManager:
    current_inferencer: Inferencer = None

    @classmethod
    def get_inferencer(cls, inferencer_type: InferencerType, model_path: Path, device_id: int,
                       inferencer_type_version: RVCInferencerOnnxVersion = None):
        try:
            cls.current_inferencer = cls.load_inferencer(inferencer_type, model_path, device_id, inferencer_type_version)
            return cls.current_inferencer
        except Exception as e:
            try:
                raise RuntimeError(e)
            finally:
                del e

    @classmethod
    def load_inferencer(cls, inferencer_type: InferencerType, model_path: Path, device_id: int,
                        inferencer_type_version: RVCInferencerOnnxVersion = None):
        if inferencer_type == 'pyTorchRVC':
            inferencer = RVCInferencerv1F0()
            inferencer.load_model(model_path, device_id)
            return inferencer
        elif inferencer_type == 'pyTorchRVCNono':
            inferencer = RVCInferencerv1NoF0()
            inferencer.load_model(model_path, device_id)
            return inferencer
        elif inferencer_type == 'pyTorchRVCv2':
            inferencer = RVCInferencerv2F0()
            inferencer.load_model(model_path, device_id)
            return inferencer
        elif inferencer_type == 'pyTorchRVCv2Nono':
            inferencer = RVCInferencerv2NoF0()
            inferencer.load_model(model_path, device_id)
            return inferencer
        elif inferencer_type == 'pyTorchDDPN':
            inferencer = RVCInferencerDDPNF0()
            inferencer.load_model(model_path, device_id)
            return inferencer
        elif inferencer_type == 'pyTorchDDPNNono':
            inferencer = RVCInferencerDDPNNoF0()
            inferencer.load_model(model_path, device_id)
            return inferencer
        elif inferencer_type == 'onnxRVC':
            inferencer = RVCInferencerOnnxF0()
            inferencer.load_model(model_path, device_id, inferencer_type_version)
            return inferencer
        elif inferencer_type == 'onnxRVCNono':
            inferencer = RVCInferencerOnnxNoF0()
            inferencer.load_model(model_path, device_id, inferencer_type_version)
            return inferencer
        else:
            raise RuntimeError(f'Unknown InferencerType {inferencer_type}')