
from pathlib import Path
from voice_chanager_const import EmbedderType
from voice_changer_data_types import EmbedderInfo
from fairseq_hubert import FairseqHubert
from embedder import Embedder

class FairseqHubertJp(FairseqHubert):

    def load_model(self, file: Path, device_id: int, layer: int, use_final_proj: bool) -> Embedder:
        super().load_model(file, device_id, layer, use_final_proj)
        return self

    def get_info(self) -> EmbedderInfo:
        if self.layer == 9:
            embedder_type = 'hubert_base_japanese_l9fp'
        elif self.layer == 12:
            embedder_type = 'hubert_base_japanese_l12'
        else:
            raise RuntimeError(f'Unknown layer {self.layer}0')
        info = EmbedderInfo(embedder_type=embedder_type, model_file=self.model_file, device_id=self.deviceId, candidate_onnx_providers=None, candidate_onnx_provider_options=None, onnx_providers=None, onnx_provider_options=None)
        return info