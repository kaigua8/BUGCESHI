

from module_manager import ModuleManager
from voice_chanager_const import PitchEstimatorType
from pitch_estimator import PitchEstimator

class PitchEstimatorManager:
    current_pitch_estimator: PitchEstimator | None = None

    @classmethod
    def get_pitch_estimator(cls, pitch_estimator_type: PitchEstimatorType, device_id: int) -> PitchEstimator:
        try:
            cls.current_pitch_estimator = cls.load_pitch_estimator(pitch_estimator_type, device_id)
            return cls.current_pitch_estimator
        except Exception as e:
            raise RuntimeError(e)

    @classmethod
    def load_pitch_estimator(cls, pitch_estimator_type: PitchEstimatorType, device_id: int) -> PitchEstimator:
        if pitch_estimator_type == 'harvest':
            from .harvest_pitch_estimator import HarvestPitchEstimator
            return HarvestPitchEstimator()
        if pitch_estimator_type == 'dio':
            from .dio_pitch_estimator import DioPitchEstimator
            return DioPitchEstimator()
        if pitch_estimator_type == 'crepe_tiny':
            from .onnxcrepe_pitch_estimator import CrepeOnnxPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('onnxcrepe_tiny.onnx')
            return CrepeOnnxPitchEstimator('crepe_tiny', path, device_id)
        if pitch_estimator_type == 'crepe_small':
            from .onnxcrepe_pitch_estimator import CrepeOnnxPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('onnxcrepe_small.onnx')
            return CrepeOnnxPitchEstimator('crepe_small', path, device_id)
        if pitch_estimator_type == 'crepe_medium':
            from .onnxcrepe_pitch_estimator import CrepeOnnxPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('onnxcrepe_medium.onnx')
            return CrepeOnnxPitchEstimator('crepe_medium', path, device_id)
        if pitch_estimator_type == 'crepe_large':
            from .onnxcrepe_pitch_estimator import CrepeOnnxPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('onnxcrepe_large.onnx')
            return CrepeOnnxPitchEstimator('crepe_large', path, device_id)
        if pitch_estimator_type == 'crepe_full':
            from .onnxcrepe_pitch_estimator import CrepeOnnxPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('onnxcrepe_full.onnx')
            return CrepeOnnxPitchEstimator('crepe_full', path, device_id)
        if pitch_estimator_type == 'rmvpe':
            from .rmvpe_pitch_estimator import RMVPEPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('rmvpe_20231006.pt')
            return RMVPEPitchEstimator('rmvpe', path, device_id)
        if pitch_estimator_type == 'rmvpe_onnx':
            from .onnxrmvpe_pitch_estimator import RMVPEOnnxPitchEstimator
            path = ModuleManager.get_instance().get_module_filepath('rmvpe_20231006.onnx')
            return RMVPEOnnxPitchEstimator('rmvpe_onnx', path, device_id)
        if pitch_estimator_type == 'fcpe':
            from .fcpe_pitch_estimator import FCPEPitchEstimator
            return FCPEPitchEstimator('fcpe', device_id)
        raise RuntimeError(f'Unknown PitchEstimatorType {pitch_estimator_type}')