

import json
import logging
import sys
import shutil
from typing import Any, Dict, Optional
from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import swagger_ui_default_parameters
from const import LOGGER_NAME
from fileuploader import EasyFileUploader
from server_const import TMP_DIR, UPLOAD_DIR, VoiceChangerParams
from validation_error_logging_route import ValidationErrorLoggingRoute
from vcserver_rest_api_audio_device_manager import RestAPIAudioDeviceManager
from vcserver_rest_api_configuration_manager import RestAPIConfigurationManager
from vcserver_rest_api_gpu_device_manager import RestAPIGPUDeviceManager
from vcserver_rest_api_hello import RestHello
from vcserver_rest_api_module_manager import RestAPIModuleManager
from vcserver_rest_api_sample_manager import RestAPISampleManager
from vcserver_rest_api_slot_manager import RestAPISlotManager
from vcserver_rest_api_task_manager import RestAPITaskManager
from vcserver_rest_api_voice_changaer import RestAPIVoiceChanger
from audio_device_manager import AudioDeviceManager
from configuration_manager import ConfigurationManager
from gpu_device_manager import GPUDeviceManager
from module_manager import ModuleManager
from slot_manager import SlotManager
from voice_chanager_const import ConfigFile, ModelDir, ModuleDir
from voice_changer import VoiceChanger

SWAGGER_JS_URL = "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0/swagger-ui-bundle.js"
SWAGGER_CSS_URL = "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0/swagger-ui.css"
SWAGGER_FAVICON_URL = "https://fastapi.tiangolo.com/img/favicon.png"


def get_custom_swagger_ui_html(
        openapi_url: str,
        title: str,
        swagger_js_url: str = SWAGGER_JS_URL,
        swagger_css_url: str = SWAGGER_CSS_URL,
        swagger_favicon_url: str = SWAGGER_FAVICON_URL,
        oauth2_redirect_url: Optional[str] = None,
        init_oauth: Optional[Dict[str, Any]] = None,
        swagger_ui_parameters: Optional[Dict[str, Any]] = None
) -> HTMLResponse:
    current_swagger_ui_parameters = swagger_ui_default_parameters.copy()
    if swagger_ui_parameters:
        current_swagger_ui_parameters.update(swagger_ui_parameters)

    html = f'''
    <!DOCTYPE html>
    <html>
    <head>
    <link type="text/css" rel="stylesheet" href="{swagger_css_url}">
    <link rel="shortcut icon" href="{swagger_favicon_url}">
    <title>{title}</title>
    </head>
    <body>
    <div style="color:red;font-weight:600;">Note: API may be subject to change in the future.</div>
    <div id="swagger-ui"></div>
    <script src="{swagger_js_url}"></script>
    <script>
    const ui = SwaggerUIBundle({{
        url: '{openapi_url}',
    '''

    for key, value in current_swagger_ui_parameters.items():
        html += f"{json.dumps(key)}: {json.dumps(jsonable_encoder(value))},\n"

    if oauth2_redirect_url:
        html += f"oauth2RedirectUrl: window.location.origin + '{oauth2_redirect_url}',"

    html += '''
        presets: [
            SwaggerUIBundle.presets.apis,
            SwaggerUIBundle.SwaggerUIStandalonePreset
        ],
    })'''

    if init_oauth:
        html += f"\nui.initOAuth({json.dumps(jsonable_encoder(init_oauth))})"

    html += '''
    </script>
    </body>
    </html>
    '''
    return HTMLResponse(html)


class RestAPI:
    __module__ = __name__
    __qualname__ = "RestAPI"

    _instance = None

    @classmethod
    def get_instance(cls, voice_changer_params: VoiceChangerParams) -> "RestAPI":
        if cls._instance is None:
            app_fastapi = FastAPI(
                title="VCClient REST API",
                docs_url=None,
                redoc_url=None
            )
            app_fastapi.router.route_class = ValidationErrorLoggingRoute

            @app_fastapi.get("/docs", include_in_schema=False)
            def custom_swagger_ui_html():
                logger = logging.getLogger(LOGGER_NAME)
                logger.info("CUSTOM UI")
                return get_custom_swagger_ui_html(
                    openapi_url=app_fastapi.openapi_url,
                    title="VCClient API Docs"
                )

            app_fastapi.mount("/tmp", StaticFiles(directory=TMP_DIR), name="static")
            app_fastapi.mount("/upload_dir", StaticFiles(directory=UPLOAD_DIR), name="static")

            if sys.platform.startswith("darwin"):
                app_fastapi.mount(f"/{ModelDir}", StaticFiles(directory=ModelDir), name="static")
            else:
                app_fastapi.mount(f"/{ModelDir}", StaticFiles(directory=ModelDir), name="static")

            rest_hello = RestHello()
            app_fastapi.include_router(rest_hello.router)

            rest_slot_manager = RestAPISlotManager()
            app_fastapi.include_router(rest_slot_manager.router)

            rest_configuration_manager = RestAPIConfigurationManager()
            app_fastapi.include_router(rest_configuration_manager.router)

            rest_audio_device_manager = RestAPIAudioDeviceManager()
            app_fastapi.include_router(rest_audio_device_manager.router)

            rest_gpu_device_manager = RestAPIGPUDeviceManager()
            app_fastapi.include_router(rest_gpu_device_manager.router)

            rest_module_manager = RestAPIModuleManager()
            app_fastapi.include_router(rest_module_manager.router)

            rest_sample_manager = RestAPISampleManager()
            app_fastapi.include_router(rest_sample_manager.router)

            fileuploader = EasyFileUploader(UPLOAD_DIR)
            app_fastapi.include_router(fileuploader.router)

            voice_changer = RestAPIVoiceChanger()
            app_fastapi.include_router(voice_changer.router)

            task_manager = RestAPITaskManager()
            app_fastapi.include_router(task_manager.router)

            app_fastapi.router.add_api_route(
                "/api/operation/initialize",
                initialize,
                methods=["POST"]
            )
            app_fastapi.router.add_api_route(
                "/api_operation_initialize",
                initialize,
                methods=["POST"]
            )

            cls._instance = app_fastapi
        return cls._instance


def initialize():
    ConfigFile.unlink(missing_ok=True)
    shutil.rmtree(ModelDir)
    ModelDir.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(ModuleDir)
    ModuleDir.mkdir(parents=True, exist_ok=True)

    audio_device_manager = AudioDeviceManager.get_instance()
    audio_device_manager.reload_device()

    configuration_manager = ConfigurationManager.get_instance()
    configuration_manager.reload()

    gpu_device_manager = GPUDeviceManager.get_instance()
    gpu_device_manager.reload()

    module_manager = ModuleManager.get_instance()
    module_manager.reload()

    slot_manager = SlotManager.get_instance()
    slot_manager.reload()

    voice_changer = VoiceChanger.get_instance()
    voice_changer.initialize()

    return {"message": "initialized."}