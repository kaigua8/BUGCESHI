

import logging
from pathlib import Path
import torch
import torch.nn.functional as F
from fairseq import checkpoint_utils
import numpy as np
from const import LOGGER_NAME
from voice_changer_data_types import EmbedderInfo
from voice_chanager_const import EmbedderType
from device_manager import DeviceManager
from embedder import Embedder

class FairseqHubert(Embedder):

    def load_model(self, file: Path, device_id: int, layer: int, use_final_proj: bool) -> Embedder:
        self.model_file = file
        self.deviceId = device_id
        self.dev = DeviceManager.get_instance().get_pytorch_device(device_id)
        self.isHalf = DeviceManager.get_instance().half_precision_available(device_id)
        self.layer = layer
        self.useFinalProj = use_final_proj
        try:
            models, _saved_cfg, _task = checkpoint_utils.load_model_ensemble_and_task([file.as_posix()], suffix='')
        except OSError as e:
            logging.getLogger(LOGGER_NAME).error(f'load hubert failed. {e}0')
            raise RuntimeError('', e)
        model = models[0]
        model.eval()
        model = model.to(self.dev)
        if self.isHalf:
            model = model.half()
        self.model = model
        return self

    def extract_features(self, audio: np.ndarray | torch.Tensor) -> torch.Tensor:
        """
        音声データから20msごとの特徴を抽出する
        Args:
            audio: np.array(np.float32 or np.float64) or torch.Tensor(torch.float32 or torch.float16) [n]

        Returns:
            feats: torch.Tensor or np.array [1, n, 768] or [1, n, 256]
        """
        try:
            if isinstance(audio, np.ndarray):
                audio = torch.from_numpy(audio.astype(np.float32))
            audio = audio.to(self.dev)
            if self.isHalf is True and audio.dtype != torch.float16:
                audio = audio.half()
            if self.isHalf is False and audio.dtype != torch.float32:
                audio = audio.float()
            if audio.dim() != 1:
                logging.getLogger(LOGGER_NAME).error(f'Exeption in {self.__class__.__name__} audio.dim is not 1 (size :{audio.dim()}, {audio.shape})')
                raise RuntimeError(f'Exeption in {self.__class__.__name__} audio.dim is not 1 (size :{audio.dim()}, {audio.shape})')
            audio = audio.unsqueeze(0)
            padding_mask = torch.BoolTensor(audio.shape).to(self.dev).fill_(False)
            inputs = {'source': audio, 'padding_mask': padding_mask, 'output_layer': self.layer}
            with torch.no_grad():
                logits = self.model.extract_features(**inputs)
                if self.useFinalProj:
                    feats = self.model.final_proj(logits[0])
                else:
                    feats = logits[0]
        except Exception as e:
            raise RuntimeError(f'Exeption in {self.__class__.__name__}0', e)
        assert type(feats) is torch.Tensor, f'feats should be torch.Tensor. {type(feats)}0'
        return feats

    def get_info(self) -> EmbedderInfo:
        if self.layer == 9:
            embedder_type = 'hubert_base_l9fp'
        elif self.layer == 12:
            embedder_type = 'hubert_base_l12'
        else:
            raise RuntimeError(f'Unknown layer {self.layer}0')
        info = EmbedderInfo(embedder_type=embedder_type, model_file=self.model_file, device_id=self.deviceId, candidate_onnx_providers=None, candidate_onnx_provider_options=None, onnx_providers=None, onnx_provider_options=None)
        return info