#!/usr/bin/env python
# visit https://tool.lu/pyc/ for more information

import json
import logging
import sys
import shutil
import typing
from typing import Any, Dict, Optional
from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import swagger_ui_default_parameters
from vcclient_dev.const import LOGGER_NAME
from vcclient_dev.server.fileuploader.fileuploader import EasyFileUploader
from vcclient_dev.server.server_const import TMP_DIR, UPLOAD_DIR, VoiceChangerParams
from vcclient_dev.server.validation_error_logging_route import ValidationErrorLoggingRoute
from vcclient_dev.server.vcserver_rest_api_audio_device_manager import RestAPIAudioDeviceManager
from vcclient_dev.server.vcserver_rest_api_configuration_manager import RestAPIConfigurationManager
from vcclient_dev.server.vcserver_rest_api_gpu_device_manager import RestAPIGPUDeviceManager
from vcclient_dev.server.vcserver_rest_api_hello import RestHello
from vcclient_dev.server.vcserver_rest_api_module_manager import RestAPIModuleManager
from vcclient_dev.server.vcserver_rest_api_sample_manager import RestAPISampleManager
from vcclient_dev.server.vcserver_rest_api_slot_manager import RestAPISlotManager
from vcclient_dev.server.vcserver_rest_api_task_manager import RestAPITaskManager
from vcclient_dev.server.vcserver_rest_api_voice_changaer import RestAPIVoiceChanger
from vcclient_dev.voice_changer.auido_device_manager.audio_device_manager import AudioDeviceManager
from vcclient_dev.voice_changer.configuration_manager.configuration_manager import ConfigurationManager
from vcclient_dev.voice_changer.gpu_device_manager.gpu_device_manager import GPUDeviceManager
from vcclient_dev.voice_changer.module_manager.module_manager import ModuleManager
from vcclient_dev.voice_changer.slot_manager.slot_manager import SlotManager
from vcclient_dev.voice_changer.voice_chanager_const import ConfigFile, ModelDir, ModuleDir
from vcclient_dev.voice_changer.voice_change_manager.voice_changer import VoiceChanger

def get_custom_swagger_ui_html(
    openapi_url,
    title,
    swagger_js_url,
    swagger_css_url,
    swagger_favicon_url,
    oauth2_redirect_url=None,
    init_oauth=None,
    swagger_ui_parameters=None,
):
    current_swagger_ui_parameters = swagger_ui_default_parameters.copy()
    if swagger_ui_parameters:
        current_swagger_ui_parameters.update(swagger_ui_parameters)
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
    <link type="text/css" rel="stylesheet" href="{swagger_css_url}">
    <link rel="shortcut icon" href="{swagger_favicon_url}">
    <title>{title}</title>
    </head>
    <body>
    <div style="color:red;font-weight: 600;">Note: API may be subject to change in the future.</div>
    <div id="swagger-ui">
    </div>
    <script src="{swagger_js_url}"></script>
    <!-- `SwaggerUIBundle` is now available on the page -->
    <script>
    const ui = SwaggerUIBundle({{
        url: '{openapi_url}',
    """
    
    for key, value in current_swagger_ui_parameters.items():
        html += f"{json.dumps(key)}: {json.dumps(jsonable_encoder(value))},\n"
    
    if oauth2_redirect_url:
        html += f"oauth2RedirectUrl: window.location.origin + '{oauth2_redirect_url}',"
    
    html += """
    presets: [
        SwaggerUIBundle.presets.apis,
        SwaggerUIBundle.SwaggerUIStandalonePreset
        ],
    })"""
    
    if init_oauth:
        html += f"""
        ui.initOAuth({json.dumps(jsonable_encoder(init_oauth))})
        """
    
    html += """
    </script>
    </body>
    </html>
    """
    
    return HTMLResponse(html)

class RestAPI:
    _instance = None
    
    @classmethod
    def get_instance(cls, voice_changer_params):
        if cls._instance is None:
            app_fastapi = FastAPI(
                title='VCClient REST API',
                docs_url=None,
                redoc_url=None,
            )
            app_fastapi.router.route_class = ValidationErrorLoggingRoute
            
            @app_fastapi.get('/docs', include_in_schema=False)
            def custom_swagger_ui_html():
                logging.getLogger(LOGGER_NAME).info('CUSTOM UI')
                return get_custom_swagger_ui_html(app_fastapi.openapi_url, title='VCClient API Docs')
            
            app_fastapi.mount('/tmp', StaticFiles(directory=f"{TMP_DIR}"), name='static')
            app_fastapi.mount('/upload_dir', StaticFiles(directory=f"{UPLOAD_DIR}"), name='static')
            
            if sys.platform.startswith('darwin'):
                app_fastapi.mount(f"/{ModelDir}", StaticFiles(directory=ModelDir), name='static')
            else:
                app_fastapi.mount(f"/{ModelDir}", StaticFiles(directory=ModelDir), name='static')
            
            rest_hello = RestHello()
            app_fastapi.include_router(rest_hello.router)
            
            rest_slot_manager = RestAPISlotManager()
            app_fastapi.include_router(rest_slot_manager.router)
            
            rest_configuration_manager = RestAPIConfigurationManager()
            app_fastapi.include_router(rest_configuration_manager.router)
            
            rest_audio_device_manager = RestAPIAudioDeviceManager()
            app_fastapi.include_router(rest_audio_device_manager.router)
            
            rest_gpu_device_manager = RestAPIGPUDeviceManager()
            app_fastapi.include_router(rest_gpu_device_manager.router)
            
            rest_module_manager = RestAPIModuleManager()
            app_fastapi.include_router(rest_module_manager.router)
            
            rest_sample_manager = RestAPISampleManager()
            app_fastapi.include_router(rest_sample_manager.router)
            
            fileuploader = EasyFileUploader(UPLOAD_DIR)
            app_fastapi.include_router(fileuploader.router)
            
            voice_changer = RestAPIVoiceChanger()
            app_fastapi.include_router(voice_changer.router)
            
            task_manager = RestAPITaskManager()
            app_fastapi.include_router(task_manager.router)
            
            app_fastapi.router.add_api_route('/api/operation/initialize', initialize, methods=['POST'])
            app_fastapi.router.add_api_route('/api_operation_initialize', initialize, methods=['POST'])
            
            cls._instance = app_fastapi
        
        return cls._instance

def initialize():
    ConfigFile.unlink(missing_ok=True)
    shutil.rmtree(ModelDir)
    ModelDir.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(ModuleDir)
    ModuleDir.mkdir(parents=True, exist_ok=True)
    
    audio_device_manager = AudioDeviceManager.get_instance()
    audio_device_manager.reload_device()
    
    configuration_manager = ConfigurationManager.get_instance()
    configuration_manager.reload()
    
    gpu_device_manager = GPUDeviceManager.get_instance()
    gpu_device_manager.reload()
    
    moduele_manager = ModuleManager.get_instance()
    moduele_manager.reload()
    
    slot_manager = SlotManager.get_instance()
    slot_manager.reload()
    
    voice_changer = VoiceChanger.get_instance()
    voice_changer.initialize()
    
    return {"message": "initialized."}
