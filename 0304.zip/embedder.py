

from abc import ABC, abstractmethod
import numpy as np
import torch
from voice_changer_data_types import EmbedderInfo

class Embedder(ABC):

    @abstractmethod
    def extract_features(self, audio: np.ndarray | torch.Tensor) -> torch.Tensor | np.ndarray:
        """b'\\n        \\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x83\\x87\\xe3\\x83\\xbc\\xe3\\x82\\xbf\\xe3\\x81\\x8b\\xe3\\x82\\x8910ms\\xe3\\x81\\x94\\xe3\\x81\\xa8\\xe3\\x81\\xae\\xe7\\x89\\xb9\\xe5\\xbe\\xb4\\xe3\\x82\\x92\\xe6\\x8a\\xbd\\xe5\\x87\\xba\\xe3\\x81\\x99\\xe3\\x82\\x8b\\n        Args:\\n            audio: np.array(np.float32 or np.float64) or torch.Tensor(torch.float32 or torch.float16) [n]\\n\\n        Returns:\\n            feats: torch.Tensor or np.array [1, n, 768] or [1, n, 256]\\n        '"""
        return

    @abstractmethod
    def get_info(self) -> EmbedderInfo:
        return