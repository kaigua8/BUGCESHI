from data_types import RVCSampleInfo, SampleInfoMember

# 创建多个 RVCSampleInfo 实例，每个实例代表一个测试样本
sample1 = RVCSampleInfo(
    id='test-ddpn-v1-f0-48k-l9-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-ddpn-v1-f0-48k-l9-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v1-f0-48k-l9-hubert/amitaro_48_f0_256_2-10.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=True,
    inferencer_type='pyTorchDDPN'
)

sample2 = RVCSampleInfo(
    id='test-ddpn-v1-nof0-48k-l9-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-ddpn-v1-nof0-48k-l9-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v1-nof0-48k-l9-hubert/amitaro_48_nof0_256_2-10.pth',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=False,
    inferencer_type='pyTorchDDPNNono'
)

sample3 = RVCSampleInfo(
    id='test-ddpn-v2-f0-40k-l12-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-ddpn-v2-f0-40k-l12-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert/test-ddpn-v2-f0-40k-l12-hubert.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert/test-ddpn-v2-f0-40k-l12-hubert.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchDDPN'
)

sample4 = RVCSampleInfo(
    id='test-ddpn-v2-nof0-40k-l12-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-ddpn-v2-nof0-40k-l12-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert/test-ddpn-v2-nof0-40k-l12-hubert.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert/test-ddpn-v2-nof0-40k-l12-hubert.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchDDPNNono'
)

sample5 = RVCSampleInfo(
    id='test-ddpn-v2-f0-40k-l12-hubert_jp_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-ddpn-v2-f0-40k-l12-hubert_jp_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert_jp/test-ddpn-v2-f0-40k-l12-hubert_jp.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert_jp/test-ddpn-v2-f0-40k-l12-hubert_jp.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchDDPN'
)

sample6 = RVCSampleInfo(
    id='test-ddpn-v2-nof0-40k-l12-hubert_jp_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-ddpn-v2-nof0-40k-l12-hubert_jp_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert_jp/test-ddpn-v2-nof0-40k-l12-hubert_jp.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert_jp/test-ddpn-v2-nof0-40k-l12-hubert_jp.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchDDPNNono'
)

sample7 = RVCSampleInfo(
    id='test-ddpn-v1-f0-48k-l9-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-ddpn-v1-f0-48k-l9-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v1-f0-48k-l9-hubert/amitaro_48_f0_256_2-10_simple.onnx',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample8 = RVCSampleInfo(
    id='test-ddpn-v1-nof0-48k-l9-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-ddpn-v1-nof0-48k-l9-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v1-nof0-48k-l9-hubert/amitaro_48_nof0_256_2-10_simple.onnx',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

sample9 = RVCSampleInfo(
    id='test-ddpn-v2-f0-40k-l12-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-ddpn-v2-f0-40k-l12-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert/test-ddpn-v2-f0-40k-l12-hubert_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert/test-ddpn-v2-f0-40k-l12-hubert.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample10 = RVCSampleInfo(
    id='test-ddpn-v2-nof0-40k-l12-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-ddpn-v2-nof0-40k-l12-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert/test-ddpn-v2-nof0-40k-l12-hubert_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert/test-ddpn-v2-nof0-40k-l12-hubert.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

sample11 = RVCSampleInfo(
    id='test-ddpn-v2-f0-40k-l12-hubert_jp_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-ddpn-v2-f0-40k-l12-hubert_jp_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert_jp/test-ddpn-v2-f0-40k-l12-hubert_jp_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-f0-40k-l12-hubert_jp/test-ddpn-v2-f0-40k-l12-hubert_jp.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample12 = RVCSampleInfo(
    id='test-ddpn-v2-nof0-40k-l12-hubert_jp_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-ddpn-v2-nof0-40k-l12-hubert_jp_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert_jp/test-ddpn-v2-nof0-40k-l12-hubert_jp_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v2-nof0-40k-l12-hubert_jp/test-ddpn-v2-nof0-40k-l12-hubert_jp.0.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

sample13 = RVCSampleInfo(
    id='test-ddpn-v1-f0-48k-l9-hubert_o_full',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx', 'full'],
    name='test-ddpn-v1-f0-48k-l9-hubert_o_full',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v1-f0-48k-l9-hubert/amitaro_48_f0_256_2-10_simple_full.onnx',
    index_url=None,
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=True,
    inferencer_type='onnxRVC'
)
SAMPLE_RVC_TEST_DDPN = [
    sample1, sample2, sample3, sample4, sample5, sample6,
    sample7, sample8, sample9, sample10, sample11, sample12, sample13
]
# sample14 = RVCSampleInfo(
#     id='test-ddpn-v1-nof0-48k-l9-hubert_o_full',
#     voice_changer_type='RVC',
#     lang='ja-JP',
#     tag=['test', 'onnx', 'full'],
#     name='test-ddpn-v1-nof0-48k-l9-hubert_o_full',
#     model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-ddpn-v1-nof0-48k-l9-hubert/amitaro_48_nof0_256_2-10_simple_full.onnx',
#     index_url=None,
#     terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt')