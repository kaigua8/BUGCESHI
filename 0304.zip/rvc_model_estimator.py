

import json
import logging
from pathlib import Path
from typing import Any
import torch
import onnxruntime
from exception import ERROR_CODE_RVC_INVALID_CONFIG_LEGNTH, ERROR_CODE_ESTIMATE_RVC_MODEL_FAILED, ERROR_CODE_RVC_INVALID_F0_VALUE, ERROR_CODE_RVC_INVALID_ONNX_MODEL, ERROR_CODE_RVC_INVALID_ONNX_MODEL_VERSION_VALUE, ERROR_CODE_RVC_INVALID_TORCH_MODEL, ERROR_CODE_RVC_INVALID_TORCH_MODEL_VERSION_VALUE, ERROR_CODE_RVC_UNKNOWN_EMBEDDER, VCClientError
from const import LOGGER_NAME
from slot_manager_data_types import RVCSlotInfo
from voice_chanager_const import InferencerType


def estimate_rvc_model(model_path):
    if not model_path.exists():
        raise AssertionError(f"Model file not found: {model_path}")
    if model_path.suffix == '.pth':
        return estimate_rvc_model_pytorch(model_path)
    elif model_path.suffix == '.onnx':
        return estimate_rvc_model_onnx(model_path)
    logger = logging.getLogger(LOGGER_NAME)
    logger.error(f"input file: {model_path}")
    raise VCClientError(ERROR_CODE_ESTIMATE_RVC_MODEL_FAILED, f"input file: {model_path}")


def estimate_rvc_model_pytorch(model_path):
    cpt = torch.load(model_path, map_location='cpu')
    config_len = len(cpt['config'])
    version = cpt.get('version', 'v1')
    if version is None:
        version = 'v1'
    sample_rate = cpt['config'][-1]
    if config_len == 18:
        training_by = 'official'
    elif config_len == 19:
        training_by = 'ddpn'
    else:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"config_len: {config_len}")
        VCClientError(ERROR_CODE_RVC_INVALID_CONFIG_LEGNTH, f"config_len: {config_len}")
    if cpt['f0'] == 1:
        is_f0 = True
    elif cpt['f0'] == 0:
        is_f0 = False
    else:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"Invalid f0 value: {cpt['f0']}")
        VCClientError(ERROR_CODE_RVC_INVALID_F0_VALUE, f"Invalid f0 value: {cpt['f0']}")
    if version == 'v1':
        torch_version = 'v1'
    elif version == 'v2':
        torch_version = 'v2'
    else:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"Invalid torch version: {version}")
        VCClientError(ERROR_CODE_RVC_INVALID_TORCH_MODEL_VERSION_VALUE, f"Invalid torch version: {version}")
    if training_by == 'official' and is_f0 and torch_version == 'v1':
        inferencer_type = 'pyTorchRVC'
        embedder = 'hubert_base_l9fp'
    elif training_by == 'official' and not is_f0 and torch_version == 'v1':
        inferencer_type = 'pyTorchRVCNono'
        embedder = 'hubert_base_l9fp'
    elif training_by == 'official' and is_f0 and torch_version == 'v2':
        inferencer_type = 'pyTorchRVCv2'
        embedder = 'hubert_base_l12'
    elif training_by == 'official' and not is_f0 and torch_version == 'v2':
        inferencer_type = 'pyTorchRVCv2Nono'
        embedder = 'hubert_base_l12'
    elif training_by == 'ddpn':
        if is_f0:
            inferencer_type = 'pyTorchDDPN'
        else:
            inferencer_type = 'pyTorchDDPNNono'
        emb_channels = cpt['config'][17]
        embedder_name = cpt['embedder_name']
        if embedder_name == 'hubert_base' and emb_channels == 256:
            embedder = 'hubert_base_l9fp'
        elif embedder_name == 'contentvec' and emb_channels == 256:
            embedder = 'hubert_base_l9fp'
        elif embedder_name == 'hubert-base-japanese' and emb_channels == 256:
            embedder = 'hubert_base_japanese_l9fp'
        elif embedder_name == 'hubert_base' and emb_channels == 768:
            embedder = 'hubert_base_l12'
        elif embedder_name == 'contentvec' and emb_channels == 768:
            embedder = 'hubert_base_l12'
        elif embedder_name == 'hubert-base-japanese' and emb_channels == 768:
            embedder = 'hubert_base_japanese_l12'
        else:
            logger = logging.getLogger(LOGGER_NAME)
            logger.error(f"Invalid embedder: {embedder_name}, emb_channels: {emb_channels}")
            raise VCClientError(ERROR_CODE_RVC_UNKNOWN_EMBEDDER, f"Invalid embedder: {embedder_name}, emb_channels: {emb_channels}")
    else:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"Invalid model: training_by {training_by}, is_f0 {is_f0}, torch_version {torch_version}")
        raise VCClientError(ERROR_CODE_RVC_INVALID_TORCH_MODEL, f"Invalid model: training_by {training_by}, is_f0 {is_f0}, torch_version {torch_version}")
    return RVCSlotInfo(
        slot_index=-1,
        name='',
        description='',
        credit='',
        terms_of_use_url='',
        icon_file=None,
        speakers={},
        model_file=Path(model_path.name),
        index_file=None,
        is_onnx=False,
        inferencer_type=inferencer_type,
        sample_rate=sample_rate,
        is_f0=is_f0,
        deprecated=False,
        embedder=embedder,
        pitch_estimator='rmvpe_onnx',
        sample_id=None,
        version=version,
        chunk_sec=0.5,
        pitch_shift=0,
        index_ratio=0,
        protect_ratio=0.5
    )


def estimate_rvc_model_onnx(model_path):
    tmp_onnx_session = onnxruntime.InferenceSession(str(model_path), providers=['CPUExecutionProvider'])
    modelmeta = tmp_onnx_session.get_modelmeta()
    input_shapes = []
    for input_node in tmp_onnx_session.get_inputs():
        input_shapes.append(input_node.shape)
    output_shapes = []
    for output_node in tmp_onnx_session.get_outputs():
        output_shapes.append(output_node.shape)
    try:
        metadata = json.loads(modelmeta.custom_metadata_map['metadata'])
        logger = logging.getLogger(LOGGER_NAME)
        logger.info(f"Trying to import onnx model: {metadata}")
        logger.info(f"Input shapes: {input_shapes}")
        logger.info(f"Output shapes: {output_shapes}")
        if metadata['version'] == '3.0':
            return onnx_v3_x(metadata, model_path)
        return onnx_v2_x(metadata, model_path)
    except Exception as e:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"Failed to load metadata: {e}")
        raise VCClientError(ERROR_CODE_RVC_INVALID_ONNX_MODEL, f"Failed to load metadata: {e}")


def onnx_v3_x(metadata, model_path):
    if metadata['version'] == '3.0':
        version = 'v3.0'
    else:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"Invalid onnx model version: {metadata['version']}")
        raise VCClientError(ERROR_CODE_RVC_INVALID_ONNX_MODEL_VERSION_VALUE, f"Invalid version: {metadata['version']}")
    if metadata['f0'] == 1:
        inferencer_type = 'onnxRVC'
        is_f0 = True
    else:
        inferencer_type = 'onnxRVCNono'
        is_f0 = False
    return RVCSlotInfo(
        slot_index=-1,
        name='',
        description='',
        credit='',
        terms_of_use_url='',
        icon_file=None,
        speakers={},
        model_file=Path(model_path.name),
        index_file=None,
        is_onnx=True,
        inferencer_type=inferencer_type,
        sample_rate=metadata['samplingRate'],
        is_f0=is_f0,
        deprecated=False,
        embedder=metadata['embedder'],
        pitch_estimator='rmvpe_onnx',
        sample_id=None,
        version=version,
        chunk_sec=0.5,
        pitch_shift=0,
        index_ratio=0,
        protect_ratio=0.5
    )


def onnx_v2_x(metadata, model_path):
    if metadata['embChannels'] == 256 and metadata['embOutputLayer'] == 9 and metadata['useFinalProj'] is True:
        if metadata['embedder'] == 'hubert-base-japanese':
            embedder = 'hubert_base_japanese_l9fp'
        else:
            embedder = 'hubert_base_l9fp'
    elif metadata['embChannels'] == 768 and metadata['embOutputLayer'] == 12 and metadata['useFinalProj'] is False:
        if metadata['embedder'] == 'hubert-base-japanese':
            embedder = 'hubert_base_japanese_l12'
        else:
            embedder = 'hubert_base_l12'
    else:
        logger = logging.getLogger(LOGGER_NAME)
        logger.error(f"Invalid embedder: {metadata['embedder_name']}, emb_channels: {metadata['embChannels']}")
        raise VCClientError(ERROR_CODE_RVC_INVALID_ONNX_MODEL, f"Invalid embedder: {metadata['embedder_name']}, emb_channels: {metadata['embChannels']}")
    embedder_legacy = metadata['embedder']
    logger = logging.getLogger(LOGGER_NAME)
    logger.info(f"Trying to import onnx model ---------- embedder_legacy: {embedder_legacy}")
    if metadata['embChannels'] == 256:
        if metadata['version'] == '2.1':
            version = 'v1.1'
        elif metadata['version'] == '2.3':
            version = 'v1.3'
        else:
            version = 'v1'
    elif metadata['embChannels'] == 768:
        if metadata['version'] == '2':
            version = 'v2'
        elif metadata['version'] == '2.1':
            version = 'v2.1'
        elif metadata['version'] == '2.2':
            version = 'v2.2'
    if metadata['f0'] == 1:
        inferencer_type = 'onnxRVC'
        is_f0 = True
    else:
        inferencer_type = 'onnxRVCNono'
        is_f0 = False
    return RVCSlotInfo(
        slot_index=-1,
        name='',
        description='',
        credit='',
        terms_of_use_url='',
        icon_file=None,
        speakers={},
        model_file=Path(model_path.name),
        index_file=None,
        is_onnx=True,
        inferencer_type=inferencer_type,
        sample_rate=metadata['samplingRate'],
        is_f0=is_f0,
        deprecated=False,
        embedder=embedder,
        pitch_estimator='rmvpe_onnx',
        sample_id=None,
        version=version,
        chunk_sec=0.5,
        pitch_shift=0,
        index_ratio=0,
        protect_ratio=0.5
    )
