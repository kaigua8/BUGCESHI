#!/usr/bin/env python
# visit https://tool.lu/pyc/ for more information

import socketio
from vcserver_socketio_namespace import SocketIONamespace

class SocketIOServer(socketio.AsyncServer):
    _instance: None = None
    
    @classmethod
    def get_instance(cls, allowed_origins: list[str] | None = None):
        if cls._instance is None:
            if allowed_origins is None:
                sio = cls('asgi', async_mode='async_mode')
            else:
                sio = cls('asgi', allowed_origins, async_mode='async_mode', cors_allowed_origins='cors_allowed_origins')
            
            cls._instance = sio
            namespace = SocketIONamespace.get_instance(cls._instance.list_all_sids)
            sio.register_namespace(namespace)
            return cls._instance
        
        return cls._instance
        
    def list_all_sids(self, namespace='/', room=None):
        return [sid for sid in self.manager.get_participants(namespace, room=room)]
