
import platform
import signal
import threading
import time
import fire
from pathlib import Path
import multiprocessing as mp
import json
from tqdm import tqdm
from Timer import Timer
from app_status import AppStatus
from client_launcher import ClientLauncher
from initializer import _cehck_and_download_initial_samples, _check_and_download_rvc_modules
import logging
import sounddevice
from const import LOG_FILE, LOGGER_NAME, VERSION
from logger import setup_logger
from ngrok_proxy_manager import NgrokProxyManager
from is_running_on_colab import is_running_on_colab
from parseBoolArg import parse_bool_arg
from resolve_url import resolve_base_url
from slot_manager_data_types import RVCModelImportParam
from local_voice_changer_interface import LocalVoiceChangerInterface
setup_logger(LOGGER_NAME, LOG_FILE)
from module_manager import ModuleDownloadStatus, ModuleManager
from vcclient_cui import VCClientCUI
from vcserver import VCServer
from audio_device_manager import AudioDeviceManager
from gpu_device_manager import GPUDeviceManager
from configuration_manager import ConfigurationManager
from voice_changer import VoiceChanger
from vc_rest_client import VCRestClient
def module_download():

    def download_progreess(status: ModuleDownloadStatus):
        print(status)
    ModuleManager.get_instance().download('hubert_base', download_progreess)
    ModuleManager.get_instance().download('contentvec-f.onnx', download_progreess)
    ModuleManager.get_instance().download('rinna_hubert_base.pt', download_progreess)
    ModuleManager.get_instance().download('rinna_hubert_base-f.onnx', download_progreess)
    ModuleManager.get_instance().download('onnxcrepe_tiny.onnx', download_progreess)
    ModuleManager.get_instance().download('onnxcrepe_small.onnx', download_progreess)
    ModuleManager.get_instance().download('onnxcrepe_medium.onnx', download_progreess)
    ModuleManager.get_instance().download('onnxcrepe_large.onnx', download_progreess)
    ModuleManager.get_instance().download('onnxcrepe_full.onnx', download_progreess)
    ModuleManager.get_instance().download('rmvpe_20231006.pt', download_progreess)
    ModuleManager.get_instance().download('rmvpe_20231006.onnx', download_progreess)

def download_applio_modules():
    pbar_dict_module = {}

    def download_callback(status: list[ModuleDownloadStatus]):
        position = 0
        for s in status:
            if s.id not in pbar_dict_module:
                pbar_dict_module[s.id] = tqdm(total=100, unit='%', desc=f'Downloading {s.id[:10]}', leave=False, position=position)
                position += 1
            pbar = pbar_dict_module[s.id]
            pbar.n = int(s.progress * 100)
            pbar.refresh()
            if s.status == 'done':
                pbar.close()
    ModuleManager.get_instance().download_applio_modules(download_callback)


def start_cui(host: str='0.0.0.0', port: int=18000, https: bool=False, launch_client: bool=True, allow_origins=None, no_cui: bool=True, ngrok_token: str | None=None, ngrok_proxy_url_file: str | None=None):
    https = parse_bool_arg(https)
    launch_client = parse_bool_arg(launch_client)
    no_cui = parse_bool_arg(no_cui)
    logging.getLogger(LOGGER_NAME).info(f'Starting VCClient CUI version:{VERSION}')
    if ngrok_token is not None and https is True:
        print('ngrok with https is not supported.')
        print('use http.')
        return
    print('checking the modules...')
    _check_and_download_rvc_modules()
    _cehck_and_download_initial_samples()
    GPUDeviceManager.get_instance()
    AudioDeviceManager.get_instance()
    app_status = AppStatus.get_instance()
    allow_origins = '*'
    vcserver = VCServer.get_instance(host=host, port=port, https=https, allow_origins=allow_origins)
    vcserver_port = vcserver.start()
    if ngrok_token is not None:
        try:
            proxy_manager = NgrokProxyManager.get_instance()
            proxy_url = proxy_manager.start(vcserver_port, token=ngrok_token)
            logging.getLogger(LOGGER_NAME).info(f'NgrokProxy: {proxy_url}')
            if ngrok_proxy_url_file is not None:
                with open(ngrok_proxy_url_file, 'w') as f:
                    f.write(proxy_url)
        except Exception as e:
            logging.getLogger(LOGGER_NAME).error(f'NgrokProxy Error:{e}')
            print('NgrokProxy Error:', e)
            print('')
            print('Ngrok proxy is not launched. Shutdown server... ')
            print('')
            vcserver.stop()
            return None
    proxy_manager = None
    proxy_url = None
    if no_cui is False and platform.system() != 'Darwin':
        app = VCClientCUI(port=port, https=https, terminate_callback=app_status.stop_app)
        cui = threading.Thread(target=app.run)
        cui.start()
    else:
        base_url = resolve_base_url(https, port)
        bold_green_start = '\x1b[1;32m'
        bold_red_start = '\x1b[1;31m'
        reset = '\x1b[0m'
        title = '    vcclient    '
        urls = [['Application', base_url], ['Log(rich)', f'{base_url}/?app_mode=LogViewer'], ['Log(text)', f'{base_url}/vcclient.log'], ['API', f'{base_url}/docs'], ['License(js)', f'{base_url}/licenses-js.json'], ['License(py)', f'{base_url}/licenses-py.json']]
        if proxy_url is not None:
            urls.append(['Ngrok', proxy_url])
        key_max_length = max((len(url[0]) for url in urls))
        url_max_length = max((len(url[1]) for url in urls))
        padding = (key_max_length + url_max_length + 3 - len(title)) // 2
        if platform.system() != 'Darwin':

            def gradient_text(text, start_color, end_color):
                text_color = (0, 255, 0)
                n = len(text)
                grad_text = ''
                for i, char in enumerate(text):
                    r = int(start_color[0] + (end_color[0] - start_color[0]) * i / n)
                    g = int(start_color[1] + (end_color[1] - start_color[1]) * i / n)
                    b = int(start_color[2] + (end_color[2] - start_color[2]) * i / n)
                    grad_text += f'\x1b[1m\x1b[38;2;{text_color[0]};{text_color[1]};{text_color[2]}m\x1b[48;2;{r};{g};{b}m{char}'
                return grad_text + reset
            start_color = (18, 121, 255)
            end_color = (0, 58, 158)
            print('')
            print(' ' * padding + gradient_text(' ' * len(title), start_color, end_color))
            print(' ' * padding + gradient_text(title, start_color, end_color))
            print(' ' * padding + gradient_text(' ' * len(title), start_color, end_color))
        else:
            print('')
            print(f'{bold_green_start}{title}{reset}')
            print('')
        print('-' * (key_max_length + url_max_length + 5))
        for url in urls:
            print(f' {bold_green_start}{url[0].ljust(key_max_length)}{reset} | {url[1]} ')
        print('-' * (key_max_length + url_max_length + 5))
        print(f'{bold_green_start}Please press Ctrl+C once to exit vcclient.{reset}')
    clinet_launcher = ClientLauncher(app_status.stop_app)
    clinet_launcher.launch(port, https)
    if is_running_on_colab():
        logging.getLogger(LOGGER_NAME).info('Colab Environment Detected.')
        while True:
            current_time = time.strftime('%Y/%m/%d %H:%M:%S')
            logging.getLogger(LOGGER_NAME).info(f'{current_time}: running...')
            if app_status.end_flag is True:
                break
            time.sleep(60)
    else:
        err_msg = ''
        try:
            while True:
                conf = ConfigurationManager.get_instance().get_voice_changer_configuration()
                local_voice_changer_interface = LocalVoiceChangerInterface.get_instance()
                if conf.voice_changer_input_mode == 'server' and local_voice_changer_interface.local_voice_changer_enabled is True:
                    local_voice_changer_interface.run()
                if app_status.end_flag is True:
                    break
                time.sleep(0.3)
        except KeyboardInterrupt:
            err_msg = 'KeyboardInterrupt'
        except sounddevice.PortAudioError as e:
            err_msg = f'sounde device error:{e}'
            import traceback
            logging.getLogger(LOGGER_NAME).error(f'Error:{e}')
            logging.getLogger(LOGGER_NAME).error(f'traceback:{traceback.format_exc()}')
            wasapi_not_supported_msg = 'If you are using WASAPI or ASIO, your device might not be compatible with it. Please try using MME instead.'
            logging.getLogger(LOGGER_NAME).error(wasapi_not_supported_msg)
            print(err_msg)
            print(f' {bold_red_start}{wasapi_not_supported_msg}{reset} ')
            time.sleep(3)
        except Exception as e:
            err_msg = f'Error:{e}'
            import traceback
            logging.getLogger(LOGGER_NAME).error(f'Error:{e}')
            logging.getLogger(LOGGER_NAME).error(f'traceback:{traceback.format_exc()}')
            print(err_msg)
            time.sleep(1)
    print(f'{bold_green_start}terminate vcclient...{reset}')

    def ignore_ctrl_c(signum, frame):
        print(f'{bold_green_start}Ctrl+C is disabled during this process{reset}')
    original_handler = signal.getsignal(signal.SIGINT)
    try:
        signal.signal(signal.SIGINT, ignore_ctrl_c)
        if launch_client:
            clinet_launcher.stop()
        print(f'{bold_green_start}vcclient is terminating...{reset}')
        vcserver.stop()
        print(f'{bold_green_start}vcclient is terminated.[{vcserver_port}]{reset}')
        if no_cui is False:
            if cui.is_alive():
                app.action_quit_server()
            cui.join()
        VoiceChanger.get_instance().stop_convert_chunk_bulk()
        if len(err_msg) > 0:
            print('msg: ', err_msg)
        if proxy_manager is not None:
            proxy_manager.stop()
    finally:
        print('')
    signal.signal(signal.SIGINT, original_handler)

def rest_client(slot_index: int, input_file: str, output_file: str):

    client = VCRestClient.get_instance()
    with Timer('audio_input_devices'):
        devs = client.get_audio_input_devices()
        print(json.dumps(devs, indent=4))
    with Timer('audio_output_devices'):
        devs = client.get_audio_output_devices()
        print(json.dumps(devs))
    test_model_dir = Path('../vcclient_model/test/')
    import_param = RVCModelImportParam(name='REST_API_MODEL', model_file=test_model_dir / 'test-official-v2-f0-40k-l12-hubert/test-official-v2-f0-40k-l12-hubert_simple_full.onnx', index_file=None, icon_file=None)
    client.upload_rvc_model(import_param)
    conf = client.get_configuration()
    conf.current_slot_index = slot_index
    client.update_configuration(conf)
    with Timer('convert:'):
        client.convert_file(input_file, output_file)

def convert_file(slot_index: int, input_file: str, output_file: str):
    vc = VoiceChanger.get_instance()
    conf = ConfigurationManager.get_instance().get_voice_changer_configuration()
    conf.current_slot_index = slot_index
    ConfigurationManager.get_instance().set_voice_changer_configuration(conf)
    vc.convert_file(input_file, output_file)

def main():
    mp.freeze_support()
    fire.Fire({'module_download': module_download, 'cui': start_cui, 'download_applio_modules': download_applio_modules, 'rest_client': rest_client, 'convert_file': convert_file})
if __name__ == '__main__':
    main()