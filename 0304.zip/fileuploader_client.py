

from typing import Any, Tuple
import pycurl
from io import BytesIO
from pathlib import Path

def upload_file(base_url: str, file_path: Path):
    chunk_size = 10485760
    chunks = []
    with open(file_path, 'rb') as file:
        while True:
            chunk = file.read(chunk_size)
            if not chunk:
                break
            chunks.append(chunk)
    c = pycurl.Curl()
    for i, chunk in enumerate(chunks):
        data = {'filename': str(file_path), 'index': str(i)}
        files = {'file': chunk}
        c.setopt(pycurl.URL, f'{base_url}/api/uploader/upload_file_chunk')
        c.setopt(pycurl.POST, 1)
        post_data = []
        for key, value_d in data.items():
            post_data.append((key, value_d))
        for key, value_f in files.items():
            post_data.append((key, (pycurl.FORM_BUFFER, key, pycurl.FORM_BUFFERPTR, value_f)))
        c.setopt(pycurl.HTTPPOST, post_data)
        buffer = BytesIO()
        c.setopt(pycurl.WRITEDATA, buffer)
        c.perform()
        response_code = c.getinfo(pycurl.RESPONSE_CODE)
        assert response_code == 200
    else:
        data = {'filename': str(file_path), 'filename_chunk_num': str(len(chunks))}
        c.setopt(pycurl.URL, f'{base_url}/api/uploader/concat_uploaded_file_chunk')
        c.setopt(pycurl.POST, 1)
        post_data = []
        for key, value in data.items():
            post_data.append((key, value))
        c.setopt(pycurl.HTTPPOST, post_data)
        buffer = BytesIO()
        c.setopt(pycurl.WRITEDATA, buffer)
        c.perform()
        response_code = c.getinfo(pycurl.RESPONSE_CODE)
        assert response_code == 200
        c.close()