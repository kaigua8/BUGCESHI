
from abc import abstractmethod
import torch
import numpy as np
from inferencer import Inferencer

class RVCInferencer(Inferencer):

    @abstractmethod
    def infer(self, feats: np.ndarray | torch.Tensor, pitch_length: np.ndarray | torch.Tensor, pitch: np.ndarray | torch.Tensor | None, pitchf: np.ndarray | torch.Tensor | None, sid: np.ndarray | torch.Tensor, convert_length: int | None=None) -> torch.Tensor | np.ndarray:
        """b'\\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x82\\x92\\xe6\\x8e\\xa8\\xe8\\xab\\x96\\xe3\\x81\\x99\\xe3\\x82\\x8b\\n\\n        \\xe3\\x83\\xbb\\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x82\\x92\\xe6\\x8e\\xa8\\xe8\\xab\\x96\\xe3\\x81\\x99\\xe3\\x82\\x8b\\n\\n        Args:\\n            feats: Any: np.array(np.float32) \\xe3\\x81\\x8b torch.Tensor(torch.float32\\xe3\\x81\\x8btorch.float16)\\xe3\\x80\\x82[1,n,768/256]\\n            featsLength: Any: np.array(np.int64) \\xe3\\x81\\x8b torch.Tensor(torch.int64)\\xe3\\x80\\x82[1]\\n            pitch: Any: np.array(np.int64)\\xe3\\x81\\x8btorch.Tensor(torch.int32) [1,n]\\n            pitchFloat: Any: np.array(np.float32, np.float64) \\xe3\\x81\\x8b torch.Tensor(torch.float32) [1,n]\\n            sid: Any: np.array(np.int64)\\xe3\\x81\\x8btorch.Tensor(torch.int64) [1]\\n            convert_length: int: \\xe5\\x87\\xba\\xe5\\x8a\\x9b\\xe3\\x81\\x99\\xe3\\x82\\x8b\\xe9\\x9f\\xb3\\xe5\\xa3\\xb0\\xe3\\x81\\xae\\xe9\\x95\\xb7\\xe3\\x81\\x95\\xe3\\x80\\x82\\n        Returns:\\n            audio:  torch.Tensor[n]\\n\\n        '"""
        return