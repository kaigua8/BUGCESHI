

import logging
from pathlib import Path
from typing import Any, cast
import numpy as np
import torch.nn.functional as F
import torch
import faiss
from onnx import TensorProto
from onnx.helper import make_model, make_node, make_graph, make_tensor_value_info, make_opsetid
import onnxruntime
from device_manager import DeviceManager
from const import LOGGER_NAME
from voice_changer_data_types import PipelineInfoMember, RVCInferencerInfo, RVCPipelineInfo
from voice_chanager_const import ModelDir, PitchEstimatorType, RVCInferencerOnnxVersion
from configuration_manager import ConfigurationManager
from slot_manager_data_types import RVCSlotInfo, SlotInfoMember
from slot_manager import SlotManager
from inferrencer_manager import InferencerManager
from rvc_inferencer import RVCInferencer
from embedder_manager import EmbedderManager
from pitch_estimator_manager import PitchEstimatorManager
from vc_pipeline import VCPipeline

class RVCPipeline(VCPipeline):
    processing_window = 160
    rvc: RVCInferencer

    def __init__(self, slot_info: SlotInfoMember):
        assert isinstance(slot_info, RVCSlotInfo)
        self.slot_info = slot_info
        self.slot_index = self.slot_info.slot_index
        conf = ConfigurationManager.get_instance().get_voice_changer_configuration()
        self.gpu_device_id = conf.gpu_device_id_int
        self.pitch_estimator_type = self.slot_info.pitch_estimator
        logging.getLogger(LOGGER_NAME).info(f'construct new pipelinepitch: slot_index:{self.slot_index}, gpu_device_id:{self.gpu_device_id} pitch_estimator: {self.pitch_estimator_type}')
        self.pitch_estimator = PitchEstimatorManager.get_pitch_estimator(self.slot_info.pitch_estimator, conf.gpu_device_id_int)
        self.embedder = EmbedderManager.get_embedder(self.slot_info.embedder, conf.gpu_device_id_int)
        assert self.slot_info.model_file is not None
        self.rvc = cast(RVCInferencer, InferencerManager.get_inferencer(self.slot_info.inferencer_type, ModelDir / str(self.slot_info.slot_index) / self.slot_info.model_file, conf.gpu_device_id_int, inferencer_type_version=cast(RVCInferencerOnnxVersion, slot_info.version)))
        if self.slot_info.index_file is not None:
            index, big_npy = self._load_index(ModelDir / str(self.slot_info.slot_index) / self.slot_info.index_file)
        else:
            index, big_npy = (None, None)
        self.index = index
        self.big_npy = big_npy
        embedder_dim_size = 256 if self.slot_info.embedder == 'hubert_base_japanese_l9fp' or self.slot_info.embedder == 'hubert_base_l9fp' else 768
        self.onnx_upscaler = self.make_onnx_upscaler(embedder_dim_size, conf.gpu_device_id_int)
        self.audio_buffer = np.zeros([16384], dtype=float)
        self.pitchf_buffer = np.zeros([1, 1], dtype=np.float64)
        if self.slot_info.embedder == 'hubert_base_l12' or self.slot_info.embedder == 'hubert_base_japanese_l12':
            self.feature_buffer = np.zeros([1, 1, 768], dtype=np.float64)
        else:
            self.feature_buffer = np.zeros([1, 1, 256], dtype=np.float64)
        self.prev_vol = 0.0

    def _load_index(self, index_file: Path):
        try:
            index = faiss.read_index(str(index_file))
        except Exception as e:
            logging.getLogger(LOGGER_NAME).error(f'load index failed. {index_file}0')
            raise e
        big_npy = index.reconstruct_n(0, index.ntotal) if index is not None else None
        return (index, big_npy)
    pass

    def make_onnx_upscaler(self, dim_size: int, gpu_device_id_int: int, ir_version: int=9):
        try:
            input = make_tensor_value_info('in', TensorProto.FLOAT, [1, dim_size, None])
            scales = make_tensor_value_info('scales', TensorProto.FLOAT, [None])
            output = make_tensor_value_info('out', TensorProto.FLOAT, [1, dim_size, None])
            resize_node = make_node('Resize', inputs=['in', '', 'scales'], outputs=['out'], mode='nearest', axes=[2])
            graph = make_graph([resize_node], 'upscaler', [input, scales], [output])
            onnx_model = make_model(graph, ir_version=ir_version, opset_imports=[make_opsetid('', 20)])
            onnx_providers, onnx_provider_options = DeviceManager.get_instance().get_onnx_execution_provider(gpu_device_id_int)
            return onnxruntime.InferenceSession(onnx_model.SerializeToString(), providers=onnx_providers, provider_options=onnx_provider_options)
        except Exception as e:
            logging.getLogger(LOGGER_NAME).error(f'make_onnx_upscaler failed. {e}0')
            print('make_onnx_upscaler failed.', e)
            raise e

    def get_input_sample_rate(self):
        return 16000

    def get_output_sample_rate(self):
        return self.slot_info.sample_rate

    def get_input_bitdepth(self):
        return np.float32

    def get_output_bitdepth(self):
        return np.float32

    def get_chunk_sec(self) -> float:
        return SlotManager.get_instance().get_slot_info(self.slot_index).chunk_sec

    def needs_crossfade(self) -> bool:
        return True

    def get_pitch_estimator_type(self) -> PitchEstimatorType:
        return self.pitch_estimator_type

    def get_gpu_device_id(self) -> int:
        return self.gpu_device_id

    def set_pitch_estimator_type(self, pitch_estimator_type: PitchEstimatorType):
        logging.getLogger(LOGGER_NAME).info(f'pitch extimator is changed: {self.pitch_estimator_type} -> {pitch_estimator_type}')
        self.pitch_estimator_type = pitch_estimator_type
        self.pitch_estimator = PitchEstimatorManager.get_pitch_estimator(self.slot_info.pitch_estimator, self.gpu_device_id)
        logging.getLogger(LOGGER_NAME).info('pitch extimator is changed: done')

    def _generate_inputs(self, audio: np.ndarray[Any, np.dtype[float]], crossfade_overlap_sec: float, sola_search_frame_sec: float, extra_frame_sec: float):
        new_frame_size = audio.shape[0]
        crossfade_overlap_size = int(crossfade_overlap_sec * self.get_input_sample_rate())
        sola_search_frame_size = int(sola_search_frame_sec * self.get_input_sample_rate())
        extra_frame_size = int(extra_frame_sec * self.get_input_sample_rate())
        self.audio_buffer = np.concatenate([self.audio_buffer, audio], 0)
        convert_size = new_frame_size + crossfade_overlap_size + sola_search_frame_size + extra_frame_size
        embedder_hop_size = self.processing_window * 1
        hop_mod = convert_size % embedder_hop_size
        if hop_mod != 0:
            convert_size = convert_size + (embedder_hop_size - hop_mod)
        real_convert_size = (new_frame_size + crossfade_overlap_size + sola_search_frame_size) * (self.get_output_sample_rate() / self.get_input_sample_rate())
        real_convert_size = int(round(real_convert_size))
        if self.audio_buffer.shape[0] < convert_size:
            self.audio_buffer = np.concatenate([np.zeros([convert_size]), self.audio_buffer])
        self.audio_buffer = self.audio_buffer[-1 * convert_size:]
        crop_offset = -1 * (new_frame_size + crossfade_overlap_size)
        crop_end = -1 * crossfade_overlap_size
        crop = self.audio_buffer[crop_offset:crop_end]
        input_volume = np.sqrt(np.square(crop).mean())
        return (self.audio_buffer, self.pitchf_buffer, self.feature_buffer, convert_size, input_volume, real_convert_size)
    pass

    def run(self, audio, real_crossfade_sec):
        # 检查音频是否为一维数组
        assert audio.ndim == 1, 'audio should be 1d.'
        # 检查音频的数据类型是否为 float32 或 float64
        assert audio.dtype in (np.float32, np.float64), f'audio should be float32 or float64. {audio.dtype}'

        input_sample_num = audio.shape[0]
        slot_manager = SlotManager.get_instance()
        slot_info = slot_manager.get_slot_info(self.slot_index)
        conf = ConfigurationManager.get_instance().get_voice_changer_configuration()
        crossfacde_overlap_sec = real_crossfade_sec
        sola_search_frame_sec = conf.sola_search_frame_sec
        extra_frame_sec = conf.extra_frame_sec

        # 检查索引和大 npy 文件是否可用
        index_enabled = (self.index is not None) and (self.big_npy is not None) and (slot_info.index_ratio > 0)

        data = self._generate_inputs(audio, crossfacde_overlap_sec, sola_search_frame_sec, extra_frame_sec)
        audio, prev_pitch, prev_feature, convert_size, vol, real_output_size = data

        reference_volume = 1
        if vol < 1e-06:
            vol_db = -np.inf
        else:
            vol_db = 20 * np.log10(vol / reference_volume)

        # 噪声门检查
        if vol_db < conf.noise_gate:
            logger = logging.getLogger(LOGGER_NAME)
            logger.info(f'noise gate {vol_db} < {conf.noise_gate}')
            return np.zeros(real_output_size).astype(float)

        # 检查是否需要估计音高
        if slot_info.is_f0:
            pitch_coarse, pitch = self.pitch_estimator.estimate(
                audio, prev_pitch, slot_info.pitch_shift,
                self.get_input_sample_rate(), self.processing_window, extra_frame_sec
            )
        else:
            pitch_coarse = None
            pitch = None

        feats = self.embedder.extract_features(audio)

        # 如果索引可用，进行特征检索
        if index_enabled:
            if isinstance(feats, np.ndarray):
                new_feats = feats[0]
            else:
                new_feats = feats[0].cpu().numpy()

            feats_length = new_feats.shape[0]
            feats_channels = new_feats.shape[1]
            latest_audio_feats_length = int(round(input_sample_num / 320))
            new_feats = new_feats[-latest_audio_feats_length:]

            if new_feats.dtype != np.float32:
                new_feats = new_feats.astype('float32')

            _, ix = self.index.search(new_feats, 1)
            new_feats_retrieved = self.big_npy[ix.squeeze()]

            if isinstance(prev_feature, np.ndarray):
                pass
            elif isinstance(prev_feature, torch.Tensor):
                prev_feature = prev_feature.cpu().numpy()

            new_feats_retrieved = np.concatenate([
                np.zeros((feats_length, feats_channels), dtype=np.float32),
                prev_feature.squeeze(axis=0).astype('float32'),
                new_feats_retrieved
            ])[-feats_length:]

            if isinstance(feats, np.ndarray):
                pass
            elif isinstance(feats, torch.Tensor):
                new_feats_retrieved = torch.from_numpy(new_feats_retrieved).unsqueeze(0).to(feats.device)
                feats = slot_info.index_ratio * new_feats_retrieved + (1 - slot_info.index_ratio) * feats

        # 特征处理
        if isinstance(feats, np.ndarray):
            if torch.cuda.is_available():
                feats = feats.transpose(0, 2, 1)
                feats = self.onnx_upscaler.run(['out'], {'in': feats, 'scales': np.array([2], dtype=np.float32)})[0]
                assert isinstance(feats[0], np.ndarray)
                feats = feats[0].transpose(0, 2, 1)
        elif isinstance(feats, torch.Tensor):
            fests = feats.permute(0, 2, 1)
            feats = F.interpolate(fests, scale_factor=2)
            assert isinstance(feats, torch.Tensor)
            feats = feats.permute(0, 2, 1)
        else:
            raise RuntimeError(f'feats should be np.ndarray or torch.Tensor. {type(feats)}')

        # 计算 npy 偏移量
        npy_offset = math.floor(extra_frame_sec * 16000) // 360
        feats = feats[:, :, npy_offset * 2:]

        # 处理音高
        if pitch is not None and pitch_coarse is not None:
            pitch = pitch[:, :feats.shape[1]]
            pitch_coarse = pitch_coarse[:, :feats.shape[1]]

        feats_len_np = np.array([feats.shape[1]], dtype=np.int64)
        sid = np.array([0], dtype=np.int64)

        # 进行推理
        converted = self.rvc.infer(
            feats, feats_len_np, pitch_coarse, pitch, sid, convert_length=real_output_size
        )
        converted = converted[:, -real_output_size:]

        self.pitchf_buffer = pitch
        self.feature_buffer = feats

        if isinstance(converted, torch.Tensor):
            converted = cast(np.ndarray, converted.cpu().numpy())

        # 音量调整
        volume_tuning_type = conf.volume_tuning_type
        if volume_tuning_type == 'linear':
            converted = converted * vol
        elif volume_tuning_type == 'linear_ratio':
            converted_vol = np.sqrt(np.square(converted).mean())
            vol_scaling_factor = vol / converted_vol
            converted = converted * vol_scaling_factor
        elif volume_tuning_type == 'sqrt':
            converted = converted * np.sqrt(vol)
        elif volume_tuning_type == 'sqrt_ratio':
            converted_vol = np.sqrt(np.square(converted).mean())
            vol_scaling_factor = np.sqrt(vol) / converted_vol
            converted = converted * vol_scaling_factor

        if isinstance(converted, torch.Tensor):
            converted = cast(np.ndarray, converted.cpu().numpy())

        return converted

    def get_pipeline_info(self) -> PipelineInfoMember:
        inferencer_info = self.rvc.get_info()
        assert isinstance(inferencer_info, RVCInferencerInfo)
        return RVCPipelineInfo(slot_index=self.slot_index, input_sample_rate=self.get_input_sample_rate(), output_sample_rate=self.get_output_sample_rate(), chunk_sec=self.get_chunk_sec(), slot_info=self.slot_info.model_dump(), embedder_info=self.embedder.get_info(), pitch_estimator_info=self.pitch_estimator.get_info(), inferencer_info=inferencer_info)