

import logging
from pathlib import Path
from typing import Callable
import math
import requests
import hashlib
from threading import Thread
from const import LOGGER_NAME
from exception import ERROR_CODE_MODULE_NOT_FOUND, VCClientError
from voice_chanager_const import ModuleDir
from data_types import ModuleInfo, ModuleStatus
from module_manager_data_types import ModuleDownloadStatus
REGISTERD_MODULES: list[ModuleInfo] = [ModuleInfo(id='hubert_base.pt', display_name='hubert_base.pt', url='https://huggingface.co/wok000/vcclient_modules/resolve/main/contentvec/hubert_base.pt', save_to=ModuleDir / Path('contentvec/hubert_base.pt'), hash='f54b40fd2802423a5643779c4861af1e9ee9c1564dc9d32f54f20b5ffba7db96'), ModuleInfo(id='contentvec-f.onnx', display_name='contentvec-f.onnx', url='https://huggingface.co/wok000/vcclient_modules/resolve/main/contentvec/contentvec-f.onnx', save_to=ModuleDir / Path('contentvec/contentvec-f.onnx'), hash='4b31ed3d95a568fab7952de923ff7f7d3d17128ea6fce69f665509d24c3156db'), ModuleInfo(id='onnxcrepe_tiny.onnx', display_name='onnxcrepe_tiny.onnx', url='https://huggingface.co/wok000/vcclient_modules/resolve/main/onnxcrepe/tiny.onnx', save_to=ModuleDir / Path('onnxcrepe/tiny.onnx'), hash='91fc2a0fd10f965dbf7775995daf50e99273caedd7efd00001f23be649da1bc3'), ModuleInfo(id='onnxcrepe_full.onnx', display_name='onnxcrepe_full.onnx', url='https://huggingface.co/wok000/vcclient_modules/resolve/main/onnxcrepe/full.onnx', save_to=ModuleDir / Path('onnxcrepe/full.onnx'), hash='119845c72c702e052e5262430f9d120bce46176689aa226c39d09dea5cc3a610'), ModuleInfo(id='rmvpe_20231006.pt', display_name='rmvpe_20231006.pt', url='https://huggingface.co/wok000/vcclient_modules/resolve/main/rmvpe/rmvpe_20231006.pt', save_to=ModuleDir / Path('rmvpe/rmvpe_20231006.pt'), hash='6d62215f4306e3ca278246188607209f09af3dc77ed4232efdd069798c4ec193'), ModuleInfo(id='rmvpe_20231006.onnx', display_name='rmvpe_20231006.onnx', url='https://huggingface.co/wok000/vcclient_modules/resolve/main/rmvpe/rmvpe_20231006.onnx', save_to=ModuleDir / Path('rmvpe/rmvpe_20231006.onnx'), hash='84f0586308e36157f75b77c8591bf636d6719c0c4ba95f8faf3df479e7566219'), ModuleInfo(id='applio_japanese_hubert_base.pt', display_name='applio_japanese_hubert_base.pt', url='https://huggingface.co/IAHispano/Applio/resolve/main/Resources/embedders/japanese_hubert_base.pt', save_to=ModuleDir / Path('applio/applio_japanese_hubert_base.pt'), hash='dade3cf824ae0d214f7de8b73e70bae7c101e81f12d93577c4760bf516db4063'), ModuleInfo(id='applio_korean_hubert_base.pt', display_name='applio_korean_hubert_base.pt', url='https://huggingface.co/IAHispano/Applio/resolve/main/Resources/embedders/korean_hubert_base.pt', save_to=ModuleDir / Path('applio/applio_korean_hubert_base.pt'), hash='6b42c8453b96b203198c1c280a8821158ea3fa8dbbc2a6220cad1c1489c3e65e')]
RVC_REQUIRED_MODULES = ['hubert_base.pt', 'contentvec-f.onnx', 'rinna_hubert_base-f.onnx', 'onnxcrepe_tiny.onnx', 'onnxcrepe_full.onnx', 'rmvpe_20231006.pt', 'rmvpe_20231006.onnx']
APPLIO_MODULES = ['applio_japanese_hubert_base.pt', 'applio_chinese_hubert_base.pt', 'applio_korean_hubert_base.pt']

class ModuleManager:
    _instance = None
    module_status_list: list[ModuleStatus] = []

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
            return cls._instance
        return cls._instance

    def __init__(self):
        self.module_status_list = []
        self.threads = {}
        self.reload()
        logging.getLogger(LOGGER_NAME).info(f'Initial module status: {self.module_status_list}')

    def reload(self):
        self.module_status_list = []
        for module_info in REGISTERD_MODULES:
            module_status = ModuleStatus(info=module_info, downloaded=False, valid=False)
            if module_info.save_to.exists():
                module_status.downloaded = True
                if self._check_hash(module_info.id):
                    module_status.valid = True
            self.module_status_list.append(module_status)

    def get_modules(self) -> list[ModuleStatus]:
        return self.module_status_list

    def _download(self, target_module: ModuleInfo, callback: Callable[[ModuleDownloadStatus], None]):
        target_module.save_to.parent.mkdir(parents=True, exist_ok=True)
        req = requests.get(target_module.url, stream=True, allow_redirects=True)
        content_length_header = req.headers.get('content-length')
        content_length = int(content_length_header) if content_length_header is not None else 1073741824
        chunk_size = 1048576
        chunk_num = math.ceil(content_length / chunk_size)
        with open(target_module.save_to, 'wb') as f:
            for i, chunk in enumerate(req.iter_content(chunk_size=chunk_size)):
                f.write(chunk)
                callback(ModuleDownloadStatus(id=target_module.id, status='processing', progress=min(1.0, round((i + 1) / chunk_num, 2))))
        callback(ModuleDownloadStatus(id=target_module.id, status='validating', progress=min(1.0, round((i + 1) / chunk_num, 2))))
        try:
            self._check_hash(target_module.id)
            logging.getLogger(LOGGER_NAME).info(f'Downloading completed: {target_module.id}')
            callback(ModuleDownloadStatus(id=target_module.id, status='done', progress=1.0))
        except Exception as e:
            logging.getLogger(LOGGER_NAME).error(f'Downloading error: {target_module.id}, {e}')
            callback(ModuleDownloadStatus(id=target_module.id, status='error', progress=1.0, error_message=str(e)))

    def _get_target_module(self, id):
        # 初始化目标模块为 None
        target_module = None
        # 遍历已注册的模块
        for module in REGISTERD_MODULES:
            # 检查当前模块的 id 是否与传入的 id 相等
            if module.id == id:
                # 如果相等，将当前模块赋值给目标模块
                target_module = module
                # 返回目标模块
                return target_module
        # 如果遍历完所有模块都没有找到匹配的 id，返回 None
        return target_module

    def download(self, id: str, callback: Callable[[ModuleDownloadStatus], None]):
        logging.getLogger(LOGGER_NAME).info(f'Downloading module: {id}0')
        target_module = self._get_target_module(id)
        if target_module is None:
            logging.getLogger(LOGGER_NAME).error(f'No such module: {id}0')
            callback(ModuleDownloadStatus(id=id, status='error', progress=1.0, error_message=f'module not found {id}0'))
            return
        for exist_trehad_id, exist_thread in list(self.threads.items()):
            if exist_thread is None or exist_thread.is_alive():
                continue
            exist_thread.join()
            self.threads.pop(exist_trehad_id)
        if id in self.threads:
            logging.getLogger(LOGGER_NAME).error(f'Already downloading: {id}0')
            callback(ModuleDownloadStatus(id=id, status='error', progress=1.0, error_message=f'module is already downloading {id}0'))
        else:
            self.threads[id] = None
            logging.getLogger(LOGGER_NAME).info(f'Start downloading: {id}0')
            t = Thread(target=self._download, args=(target_module, callback))
            t.start()
            self.threads[id] = t

    def _check_hash(self, id: str):
        target_module = self._get_target_module(id)
        if target_module is None:
            raise VCClientError(ERROR_CODE_MODULE_NOT_FOUND, f'Module {id}0 not found')
        with open(target_module.save_to, 'rb') as f:
            data = f.read()
            hash = hashlib.sha256(data).hexdigest()
            if hash != target_module.hash:
                logging.getLogger(LOGGER_NAME).error(f'hash is not valid: valid:{target_module.hash}, incoming:{hash}')
                return False
            return True

    def get_module_filepath(self, id: str):
        target_module = self._get_target_module(id)
        if target_module is None:
            return
        return target_module.save_to

    def is_rvc_ready(self) -> bool:
        for module_id in RVC_REQUIRED_MODULES:
            module_status = [module_status for module_status in self.module_status_list if module_status.info.id == module_id]
            if len(module_status) == 1:
                if not module_status[0].downloaded or not module_status[0].valid:
                    return False
            else:
                return False
        else:
            return True

    def download_rvc_modules(self, callback: Callable[[list[ModuleDownloadStatus]], None]):
        rvc_modules = [x for x in self.get_modules() if x.info.id in RVC_REQUIRED_MODULES and x.valid is False]
        status_dict = {x.info.id: ModuleDownloadStatus(id=x.info.id, status='processing', progress=0.0) for x in rvc_modules}

        def download_callback(status: ModuleDownloadStatus):
            status_dict[status.id] = status
            callback(list(status_dict.values()))
        for module in rvc_modules:
            self.download(module.info.id, download_callback)
        for threads in self.threads.values():
            threads.join()
        print('module download fin!')

    def applio_modules_ready(self) -> bool:
        applio_modules = [x for x in self.get_modules() if x.info.id in APPLIO_MODULES and x.valid is False]
        if len(applio_modules) == 0:
            return True
        return False

    def download_applio_modules(self, callback: Callable[[list[ModuleDownloadStatus]], None]):
        applio_modules = [x for x in self.get_modules() if x.info.id in APPLIO_MODULES and x.valid is False]
        status_dict = {x.info.id: ModuleDownloadStatus(id=x.info.id, status='processing', progress=0.0) for x in applio_modules}

        def download_callback(status: ModuleDownloadStatus):
            status_dict[status.id] = status
            callback(list(status_dict.values()))
        for module in applio_modules:
            self.download(module.info.id, download_callback)
        for threads in self.threads.values():
            threads.join()
        print('module download fin!')