

from abc import ABC, abstractmethod
from typing import Any
import numpy as np
from voice_changer_data_types import PipelineInfoMember
from voice_chanager_const import PitchEstimatorType

class VCPipeline(ABC):

    @abstractmethod
    def get_input_sample_rate(self) -> int:
        return

    @abstractmethod
    def get_output_sample_rate(self) -> int:
        return

    @abstractmethod
    def get_input_bitdepth(self):
        return

    @abstractmethod
    def get_output_bitdepth(self):
        return

    @abstractmethod
    def get_chunk_sec(self) -> float:
        return

    @abstractmethod
    def needs_crossfade(self) -> bool:
        return

    @abstractmethod
    def get_pitch_estimator_type(self) -> PitchEstimatorType | None:
        return

    @abstractmethod
    def get_gpu_device_id(self) -> int:
        return

    @abstractmethod
    def set_pitch_estimator_type(self, pitch_estimator_type: PitchEstimatorType):
        return

    @abstractmethod
    def get_pipeline_info(self) -> PipelineInfoMember:
        return

    @abstractmethod
    def run(self, audio: np.ndarray[Any, np.dtype[float]], real_crossfade_sec: float) -> np.ndarray[Any, np.dtype[float]]:
        return