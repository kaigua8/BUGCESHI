from data_types import RVCSampleInfo, SampleInfoMember

# 创建多个 RVCSampleInfo 实例，每个实例代表一个测试样本
sample1 = RVCSampleInfo(
    id='test-official-v1-f0-48k-l9-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-official-v1-f0-48k-l9-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-f0-48k-l9-hubert/test-official-v1-f0-48k-l9-hubert.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-f0-48k-l9-hubert/added_IVF2906_Flat_nprobe_1.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=True,
    inferencer_type='pyTorchRVC'
)

sample2 = RVCSampleInfo(
    id='test-official-v1-nof0-48k-l9-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-official-v1-nof0-48k-l9-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-nof0-48k-l9-hubert/test-official-v1-nof0-48k-l9-hubert.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-nof0-48k-l9-hubert/added_IVF2906_Flat_nprobe_1.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=False,
    inferencer_type='pyTorchRVCNono'
)

sample3 = RVCSampleInfo(
    id='test-official-v2-f0-40k-l12-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-official-v2-f0-40k-l12-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-f0-40k-l12-hubert/test-official-v2-f0-40k-l12-hubert.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-f0-40k-l12-hubert/added_IVF3139_Flat_nprobe_1_test-official-v2-f0-40k-l12-hubert_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='pyTorchRVCv2'
)

sample4 = RVCSampleInfo(
    id='test-official-v2-nof0-40k-l12-hubert_t',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'torch'],
    name='test-official-v2-nof0-40k-l12-hubert_t',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-nof0-40k-l12-hubert/test-official-v2-nof0-40k-l12-hubert.pth',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-nof0-40k-l12-hubert/added_IVF3139_Flat_nprobe_1_test-official-v2-nof0-40k-l12-hubert_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='pyTorchRVCv2Nono'
)

sample5 = RVCSampleInfo(
    id='test-official-v1-f0-48k-l9-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-official-v1-f0-48k-l9-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-f0-48k-l9-hubert/test-official-v1-f0-48k-l9-hubert_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-f0-48k-l9-hubert/added_IVF2906_Flat_nprobe_1.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample6 = RVCSampleInfo(
    id='test-official-v1-nof0-48k-l9-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-official-v1-nof0-48k-l9-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-nof0-48k-l9-hubert/test-official-v1-nof0-48k-l9-hubert_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-nof0-48k-l9-hubert/added_IVF2906_Flat_nprobe_1.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

sample7 = RVCSampleInfo(
    id='test-official-v2-f0-40k-l12-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-official-v2-f0-40k-l12-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-f0-40k-l12-hubert/test-official-v2-f0-40k-l12-hubert_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-f0-40k-l12-hubert/added_IVF3139_Flat_nprobe_1_test-official-v2-f0-40k-l12-hubert_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample8 = RVCSampleInfo(
    id='test-official-v2-nof0-40k-l12-hubert_o',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx'],
    name='test-official-v2-nof0-40k-l12-hubert_o',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-nof0-40k-l12-hubert/test-official-v2-nof0-40k-l12-hubert_simple.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-nof0-40k-l12-hubert/added_IVF3139_Flat_nprobe_1_test-official-v2-nof0-40k-l12-hubert_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

sample9 = RVCSampleInfo(
    id='test-official-v1-f0-48k-l9-hubert_o_full',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx', 'full'],
    name='test-official-v1-f0-48k-l9-hubert_o_full',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-f0-48k-l9-hubert/test-official-v1-f0-48k-l9-hubert_simple_full.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-f0-48k-l9-hubert/added_IVF2906_Flat_nprobe_1.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample10 = RVCSampleInfo(
    id='test-official-v1-nof0-48k-l9-hubert_o_full',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx', 'full'],
    name='test-official-v1-nof0-48k-l9-hubert_o_full',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-nof0-48k-l9-hubert/test-official-v1-nof0-48k-l9-hubert_simple_full.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v1-nof0-48k-l9-hubert/added_IVF2906_Flat_nprobe_1.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=48000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

sample11 = RVCSampleInfo(
    id='test-official-v2-f0-40k-l12-hubert_o_full',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx', 'full'],
    name='test-official-v2-f0-40k-l12-hubert_o_full',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-f0-40k-l12-hubert/test-official-v2-f0-40k-l12-hubert_simple_full.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-f0-40k-l12-hubert/added_IVF3139_Flat_nprobe_1_test-official-v2-f0-40k-l12-hubert_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=True,
    inferencer_type='onnxRVC'
)

sample12 = RVCSampleInfo(
    id='test-official-v2-nof0-40k-l12-hubert_o_full',
    voice_changer_type='RVC',
    lang='ja-JP',
    tag=['test', 'onnx', 'full'],
    name='test-official-v2-nof0-40k-l12-hubert_o_full',
    model_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-nof0-40k-l12-hubert/test-official-v2-nof0-40k-l12-hubert_simple_full.onnx',
    index_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/test-official-v2-nof0-40k-l12-hubert/added_IVF3139_Flat_nprobe_1_test-official-v2-nof0-40k-l12-hubert_v2.index.bin',
    terms_of_use_url='https://huggingface.co/wok000/vcclient_model/raw/main/test/term_of_use.txt',
    icon_url='https://huggingface.co/wok000/vcclient_model/resolve/main/test/dummy.png',
    credit='あみたろ',
    description='',
    sample_rate=40000,
    f0=False,
    inferencer_type='onnxRVCNono'
)

# 将所有样本存储在一个列表中
SAMPLE_RVC_TEST_OFFICIAL = [
    sample1, sample2, sample3, sample4, sample5, sample6,
    sample7, sample8, sample9, sample10, sample11, sample12
]

# 添加类型注解
# __annotations__['SAMPLE_RVC_TEST_OFFICIAL'] = list[SampleInfoMember]