

from textual.app import RenderResult
from textual.widgets import Footer

class CustomFooter(Footer):

    def render(self) -> RenderResult:
        if self._key_text is None:
            self._key_text = self._make_key_text()
        return self._key_text