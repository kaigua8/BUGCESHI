
import logging
from fastapi import APIRouter
from const import LOGGER_NAME
from validation_error_logging_route import ValidationErrorLoggingRoute
from configuration_manager import ConfigurationManager, VoiceChangerConfiguration

class RestAPIConfigurationManager:

    def __init__(self):
        self.router = APIRouter()
        self.router.route_class = ValidationErrorLoggingRoute
        self.router.add_api_route('/api/configuration-manager/configuration', self.get_configuration, methods=['GET'])
        self.router.add_api_route('/api/configuration-manager/configuration', self.put_configuration, methods=['PUT'])
        self.router.add_api_route('/api_configuration-manager_configuration', self.get_configuration, methods=['GET'])
        self.router.add_api_route('/api_configuration-manager_configuration', self.put_configuration, methods=['PUT'])

    def get_configuration(self, reload: bool=False):
        configuration_manager = ConfigurationManager.get_instance()
        if reload:
            configuration_manager.reload()
        return configuration_manager.get_voice_changer_configuration()

    def put_configuration(self, configuration: VoiceChangerConfiguration):
        """b'\\n        \\xe6\\xb3\\xa8\\xe6\\x84\\x8f: VoiceChangerConfiguration\\xe3\\x81\\xab\\xe3\\x81\\xaf\\xe5\\x88\\x9d\\xe6\\x9c\\x9f\\xe5\\x80\\xa4\\xe3\\x81\\x8c\\xe8\\xa8\\xad\\xe5\\xae\\x9a\\xe3\\x81\\x95\\xe3\\x82\\x8c\\xe3\\x81\\xa6\\xe3\\x81\\x84\\xe3\\x82\\x8b\\xe3\\x81\\xae\\xe3\\x81\\xa7\\xe3\\x80\\x81\\xe3\\x83\\x95\\xe3\\x82\\xa3\\xe3\\x83\\xbc\\xe3\\x83\\xab\\xe3\\x83\\x89\\xe3\\x81\\x8c\\xe6\\xac\\xa0\\xe3\\x81\\x91\\xe3\\x81\\xa6\\xe3\\x81\\x84\\xe3\\x81\\xa6\\xe3\\x82\\x82\\xe5\\x88\\x9d\\xe6\\x9c\\x9f\\xe5\\x80\\xa4\\xe3\\x81\\xa7\\xe8\\xa3\\x9c\\xe3\\x82\\x8f\\xe3\\x82\\x8c\\xe3\\x81\\xa6\\xe3\\x82\\xa8\\xe3\\x83\\xa9\\xe3\\x83\\xbc\\xe3\\x81\\x8c\\xe5\\x87\\xba\\xe3\\x81\\xaa\\xe3\\x81\\x84\\xe3\\x80\\x82\\n        \\xe3\\x80\\x80\\xe3\\x80\\x80\\xe3\\x80\\x80\\xe3\\x83\\x95\\xe3\\x82\\xa3\\xe3\\x83\\xbc\\xe3\\x83\\xab\\xe3\\x83\\x89\\xe3\\x81\\xae\\xe5\\x9e\\x8b\\xe3\\x81\\x8c\\xe7\\x95\\xb0\\xe3\\x81\\xaa\\xe3\\x82\\x8b\\xe5\\xa0\\xb4\\xe5\\x90\\x88\\xe3\\x81\\xaf\\xe3\\x82\\xa8\\xe3\\x83\\xa9\\xe3\\x83\\xbc\\xe3\\x81\\x8c\\xe5\\x87\\xba\\xe3\\x82\\x8b\\xe3\\x80\\x82\\n        '"""
        configuration_manager = ConfigurationManager.get_instance()
        logging.getLogger(LOGGER_NAME).info(f'Configuration updated: {configuration}')
        configuration_manager.set_voice_changer_configuration(configuration)